import secrets
import threading
import time

from flask import Flask, jsonify, redirect, render_template, request, session, url_for

import auth
import config
import port_scanner
import storage
import ufw_manager as ufw

app = Flask(__name__)


def _get_secret_key():
    data = storage.load("flask_secret.json")
    if data and data.get("key"):
        return bytes.fromhex(data["key"])
    key = secrets.token_bytes(32)
    storage.save("flask_secret.json", {"key": key.hex()})
    return key


app.secret_key = _get_secret_key()
app.config.update(SESSION_COOKIE_SAMESITE="Lax", PERMANENT_SESSION_LIFETIME=60 * 60 * 12)

_state_lock = threading.Lock()
_pending = {"active": False, "timer": None, "expires_at": 0}


def new_rule_id():
    return secrets.token_hex(4)


def ensure_bootstrap():
    if not storage.exists("running.json"):
        imported = ufw.import_from_host()
        imported["committed_at"] = None
        imported["source"] = "imported"
        storage.save("running.json", imported)
    if not storage.exists("candidate.json"):
        running = storage.load("running.json")
        storage.save("candidate.json", {
            "policies": dict(running["policies"]),
            "logging": running["logging"],
            "rules": [dict(r) for r in running["rules"]],
        })


# ---------------------------------------------------------------- auth ----

@app.before_request
def guard():
    if request.path.startswith("/static/") or request.path in ("/login", "/health"):
        return
    if not session.get("authed"):
        if request.path.startswith("/api/"):
            return jsonify({"error": "unauthorized"}), 401
        return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", error=None)
    ip = request.remote_addr or "unknown"
    if auth.is_locked(ip):
        return render_template("login.html", error="TOO MANY ATTEMPTS — LOCKED 30s"), 429
    pw = request.form.get("password", "")
    if auth.check_password(pw):
        auth.record_success(ip)
        session["authed"] = True
        session.permanent = True
        return redirect(url_for("index"))
    auth.record_fail(ip)
    return render_template("login.html", error="ACCESS DENIED — INVALID KEY")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


# --------------------------------------------------------------- pages ----

@app.route("/")
def index():
    return render_template("index.html",
                            webui_port=config.WEBUI_PORT,
                            confirm_seconds=config.COMMIT_CONFIRM_SECONDS)


# ---------------------------------------------------------------- state ----

@app.route("/api/state")
def api_state():
    running = storage.load("running.json")
    candidate = storage.load("candidate.json")
    now = time.time()
    pending = {
        "active": _pending["active"],
        "seconds_left": max(0, int(_pending["expires_at"] - now)) if _pending["active"] else 0,
    }
    return jsonify({"running": running, "candidate": candidate, "pending_commit": pending})


@app.route("/api/ufw/raw")
def api_raw():
    return jsonify({"raw": ufw.get_raw_status()})


@app.route("/api/portmap")
def api_portmap():
    against = request.args.get("against", "running")
    cfg = storage.load("candidate.json") if against == "candidate" else storage.load("running.json")
    try:
        result = port_scanner.build_portmap(cfg)
        result["scanned_at"] = time.time()
        result["against"] = against

        current_keys = {f"{e['proto']}:{e['addr']}:{e['port']}" for e in result["entries"]}
        baseline_name = "portmap_baseline.json"
        baseline = set(storage.load(baseline_name, []))
        # bool(baseline): on the very first scan ever, there's nothing to
        # compare against, so don't flood every port as "new".
        for e in result["entries"]:
            key = f"{e['proto']}:{e['addr']}:{e['port']}"
            e["is_new"] = bool(baseline) and key not in baseline
        # Only the live (running) scan advances the baseline — previewing
        # against candidate shouldn't mark "new" based on hypothetical state.
        if against == "running":
            storage.save(baseline_name, sorted(current_keys))

        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/test-connection", methods=["POST"])
def api_test_connection():
    body = request.get_json(force=True) or {}
    source_ip = (body.get("source_ip") or "any").strip() or "any"
    dest_ip = (body.get("dest_ip") or "any").strip() or "any"
    proto = body.get("proto", "tcp")
    direction = body.get("direction", "in")
    port_raw = body.get("port")

    errors = []
    if direction not in ("in", "out"):
        errors.append("Direction must be 'in' or 'out'.")
    if proto not in ("tcp", "udp"):
        errors.append("Protocol must be 'tcp' or 'udp'.")
    port = None
    try:
        port = int(port_raw)
        if not (1 <= port <= 65535):
            raise ValueError()
    except (TypeError, ValueError):
        errors.append("Port must be a number between 1 and 65535.")
    if not ufw.valid_ip_or_any(source_ip):
        errors.append(f"Invalid source address '{source_ip}'.")
    if not ufw.valid_ip_or_any(dest_ip):
        errors.append(f"Invalid destination address '{dest_ip}'.")

    if errors:
        return jsonify({"error": "invalid_input", "errors": errors}), 400

    running = storage.load("running.json")
    result = ufw.evaluate(running.get("rules", []), running.get("policies", {}),
                           direction, proto, port, source_ip, dest_ip)

    matched = result["rule"]
    if matched:
        explanation = (
            f"Matched rule: {matched['action'].upper()} {direction} {proto} "
            f"port {matched.get('port') or 'any'} from {matched.get('from_ip', 'any')} "
            f"to {matched.get('to_ip', 'any')}"
        )
        if matched.get("comment"):
            explanation += f' — "{matched["comment"]}"'
    else:
        policy_key = "incoming" if direction == "in" else "outgoing"
        default_action = running.get("policies", {}).get(policy_key, "?")
        explanation = (
            f"No rule matched — falling back to the default {policy_key} policy: "
            f"{default_action.upper()}."
        )

    return jsonify({
        "action": result["action"],
        "matched_rule": matched,
        "explanation": explanation,
        "source_ip": source_ip, "dest_ip": dest_ip,
        "port": port, "proto": proto, "direction": direction,
    })


# ---------------------------------------------------------- candidate ----

@app.route("/api/candidate/policies", methods=["POST"])
def api_candidate_policies():
    body = request.get_json(force=True) or {}
    cand = storage.load("candidate.json")
    for k in ("incoming", "outgoing", "routed"):
        if k in body.get("policies", {}):
            cand["policies"][k] = body["policies"][k]
    if "logging" in body:
        cand["logging"] = body["logging"]
    storage.save("candidate.json", cand)
    return jsonify(cand)


@app.route("/api/candidate/rules", methods=["POST"])
def api_add_rule():
    body = request.get_json(force=True) or {}
    cand = storage.load("candidate.json")
    rule = {
        "id": new_rule_id(),
        "enabled": True,
        "action": body.get("action", "allow"),
        "direction": body.get("direction", "in"),
        "proto": body.get("proto", "any"),
        "port": str(body.get("port", "")).strip(),
        "from_ip": (body.get("from_ip") or "any").strip() or "any",
        "to_ip": (body.get("to_ip") or "any").strip() or "any",
        "comment": (body.get("comment") or "").strip()[:200],
        "docker_forward": bool(body.get("docker_forward")),
    }
    cand["rules"].append(rule)
    storage.save("candidate.json", cand)
    return jsonify(cand)


@app.route("/api/candidate/rules/<rid>", methods=["PUT"])
def api_update_rule(rid):
    body = request.get_json(force=True) or {}
    cand = storage.load("candidate.json")
    for r in cand["rules"]:
        if r["id"] == rid:
            for k in ("enabled", "action", "direction", "proto", "port",
                      "from_ip", "to_ip", "comment", "docker_forward"):
                if k in body:
                    r[k] = body[k]
            break
    else:
        return jsonify({"error": "not found"}), 404
    storage.save("candidate.json", cand)
    return jsonify(cand)


@app.route("/api/candidate/rules/<rid>", methods=["DELETE"])
def api_delete_rule(rid):
    cand = storage.load("candidate.json")
    cand["rules"] = [r for r in cand["rules"] if r["id"] != rid]
    storage.save("candidate.json", cand)
    return jsonify(cand)


@app.route("/api/candidate/reorder", methods=["POST"])
def api_reorder():
    order = (request.get_json(force=True) or {}).get("order", [])
    cand = storage.load("candidate.json")
    by_id = {r["id"]: r for r in cand["rules"]}
    cand["rules"] = [by_id[i] for i in order if i in by_id]
    storage.save("candidate.json", cand)
    return jsonify(cand)


@app.route("/api/candidate/discard", methods=["POST"])
def api_discard():
    running = storage.load("running.json")
    cand = {
        "policies": dict(running["policies"]),
        "logging": running["logging"],
        "rules": [dict(r) for r in running["rules"]],
    }
    storage.save("candidate.json", cand)
    return jsonify(cand)


@app.route("/api/candidate/validate", methods=["POST"])
def api_validate():
    cand = storage.load("candidate.json")
    running = storage.load("running.json")
    result = ufw.validate_candidate(cand)
    result["diff"] = ufw.diff_configs(running, cand)
    return jsonify(result)


@app.route("/api/candidate/export")
def api_candidate_export():
    cand = storage.load("candidate.json")
    resp = jsonify(cand)
    resp.headers["Content-Disposition"] = "attachment; filename=ufw-candidate.json"
    return resp


@app.route("/api/candidate/import", methods=["POST"])
def api_candidate_import():
    body = request.get_json(force=True) or {}
    if not isinstance(body.get("rules"), list) or not isinstance(body.get("policies"), dict):
        return jsonify({"error": "invalid_format",
                         "message": "Expected an object with policies/logging/rules, "
                                    "e.g. one exported from this same tool."}), 400

    policies_in = body["policies"]
    cand = {
        "policies": {
            "incoming": policies_in.get("incoming", "deny"),
            "outgoing": policies_in.get("outgoing", "allow"),
            "routed": policies_in.get("routed", "deny"),
        },
        "logging": body.get("logging", "low"),
        "rules": [],
    }
    for r in body["rules"]:
        if not isinstance(r, dict):
            continue
        cand["rules"].append({
            "id": new_rule_id(),  # fresh ids — never trust ids from an uploaded file
            "enabled": r.get("enabled", True),
            "action": r.get("action", "allow"),
            "direction": r.get("direction", "in"),
            "proto": r.get("proto", "any"),
            "port": str(r.get("port", "")).strip(),
            "from_ip": (r.get("from_ip") or "any").strip() or "any",
            "to_ip": (r.get("to_ip") or "any").strip() or "any",
            "comment": (r.get("comment") or "").strip()[:200],
            "docker_forward": bool(r.get("docker_forward")),
        })

    validation = ufw.validate_candidate(cand)
    if validation["errors"]:
        return jsonify({"error": "validation_failed", "validation": validation}), 400

    storage.save("candidate.json", cand)
    return jsonify(cand)


# ------------------------------------------------------ commit / revert ----

def _do_auto_revert():
    with _state_lock:
        _pending["active"] = False
        _pending["timer"] = None
        if not storage.exists("snapshot.json"):
            return
        snap = storage.load("snapshot.json")
    ufw.apply_config(snap)
    snap["committed_at"] = time.time()
    snap["source"] = "auto-revert"
    storage.save("running.json", snap)
    storage.save("candidate.json", {
        "policies": dict(snap["policies"]),
        "logging": snap["logging"],
        "rules": [dict(r) for r in snap["rules"]],
    })


@app.route("/api/commit", methods=["POST"])
def api_commit():
    cand = storage.load("candidate.json")
    validation = ufw.validate_candidate(cand)
    if validation["errors"]:
        return jsonify({"error": "validation_failed", "validation": validation}), 400

    running = storage.load("running.json")
    storage.save("snapshot.json", running)

    log = ufw.apply_config(cand)

    new_running = {
        "policies": dict(cand["policies"]),
        "logging": cand["logging"],
        "rules": [dict(r) for r in cand["rules"]],
        "committed_at": time.time(),
        "source": "committed",
    }
    storage.save("running.json", new_running)

    seconds = config.COMMIT_CONFIRM_SECONDS
    with _state_lock:
        if _pending["timer"]:
            _pending["timer"].cancel()
        if seconds > 0:
            t = threading.Timer(seconds, _do_auto_revert)
            t.daemon = True
            t.start()
            _pending.update({"active": True, "timer": t, "expires_at": time.time() + seconds})
        else:
            _pending.update({"active": False, "timer": None, "expires_at": 0})

    return jsonify({
        "ok": True,
        "log": log,
        "running": new_running,
        "pending_commit": {"active": _pending["active"], "seconds_left": seconds},
    })


@app.route("/api/commit/confirm", methods=["POST"])
def api_commit_confirm():
    with _state_lock:
        if _pending["timer"]:
            _pending["timer"].cancel()
        _pending.update({"active": False, "timer": None, "expires_at": 0})
    return jsonify({"ok": True})


@app.route("/api/commit/revert", methods=["POST"])
def api_commit_revert():
    with _state_lock:
        if _pending["timer"]:
            _pending["timer"].cancel()
        _pending.update({"active": False, "timer": None, "expires_at": 0})
    _do_auto_revert()
    running = storage.load("running.json")
    return jsonify({"ok": True, "running": running})


# ------------------------------------------------------------ danger zone ----

@app.route("/api/ufw/disable", methods=["POST"])
def api_ufw_disable():
    ufw.run_ufw(["--force", "disable"])
    return jsonify({"ok": True, "raw": ufw.get_raw_status()})


@app.route("/api/ufw/enable", methods=["POST"])
def api_ufw_enable():
    ufw.run_ufw(["--force", "enable"])
    return jsonify({"ok": True, "raw": ufw.get_raw_status()})


ensure_bootstrap()
_generated_pw = auth.get_or_create_password()
if _generated_pw:
    print("=" * 64)
    print(f"  UFW WebUI — generated login password: {_generated_pw}")
    print("  Stored (hashed) in /data/auth.json. Save this now — it will")
    print("  not be printed again. Set WEBUI_PASSWORD env to override it.")
    print("=" * 64)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=config.WEBUI_PORT)

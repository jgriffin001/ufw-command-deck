import os

DATA_DIR = os.environ.get("DATA_DIR", "/data")
WEBUI_PORT = int(os.environ.get("WEBUI_PORT", "8787"))
COMMIT_CONFIRM_SECONDS = int(os.environ.get("COMMIT_CONFIRM_SECONDS", "90"))
WEBUI_PASSWORD = os.environ.get("WEBUI_PASSWORD", "")

"""Reads the host's actual listening sockets straight out of /proc (this
container shares the host network namespace already, via network_mode:
host), attributes them to a process (needs pid: host) and/or a Docker
container (needs the docker.sock mount), and cross-references each one
against ufw's running config to say whether ufw is actually doing anything
about it.

Everything here degrades gracefully: no pid namespace access -> no process
names; no docker socket -> no container attribution. Never raises out to
the caller.
"""
import glob
import ipaddress
import os
import socket
import subprocess

import ufw_manager as ufw

PROC_NET_FILES = [
    ("/proc/net/tcp", "tcp", False),
    ("/proc/net/tcp6", "tcp", True),
    ("/proc/net/udp", "udp", False),
    ("/proc/net/udp6", "udp", True),
]

TCP_LISTEN = "0A"


def _hex_to_ip(hexstr, is_ipv6):
    raw = bytes.fromhex(hexstr)
    if not is_ipv6:
        return ".".join(str(b) for b in raw[::-1])
    # Kernel stores IPv6 addresses as four little-endian 32-bit words.
    words = [raw[i:i + 4][::-1] for i in range(0, 16, 4)]
    return socket.inet_ntop(socket.AF_INET6, b"".join(words))


def _parse_proc_net_file(path, proto, is_ipv6):
    entries = []
    try:
        with open(path, "r") as f:
            lines = f.readlines()[1:]
    except (FileNotFoundError, PermissionError):
        return entries

    for line in lines:
        parts = line.split()
        if len(parts) < 10:
            continue
        local_addr_hex, local_port_hex = parts[1].split(":")
        rem_addr_hex, rem_port_hex = parts[2].split(":")
        state = parts[3]
        inode = parts[9]

        if proto == "tcp" and state != TCP_LISTEN:
            continue
        if proto == "udp" and (rem_addr_hex != "0" * len(rem_addr_hex) or rem_port_hex != "0000"):
            continue  # only "bound, not connected to a peer" UDP sockets

        try:
            addr = _hex_to_ip(local_addr_hex, is_ipv6)
            port = int(local_port_hex, 16)
        except ValueError:
            continue

        entries.append({
            "proto": proto,
            "addr": addr,
            "port": port,
            "inode": inode,
            "ipv6": is_ipv6,
        })
    return entries


def list_listening_sockets():
    out = []
    seen = set()
    for path, proto, is_ipv6 in PROC_NET_FILES:
        for e in _parse_proc_net_file(path, proto, is_ipv6):
            key = (e["proto"], e["addr"], e["port"])
            if key in seen:
                continue
            seen.add(key)
            out.append(e)
    return out


def build_inode_pid_map():
    """inode (str) -> list of pids holding an fd on that socket. Empty if we
    can't see other processes (no pid: host)."""
    mapping = {}
    for fd_path in glob.glob("/proc/[0-9]*/fd/*"):
        try:
            target = os.readlink(fd_path)
        except (OSError, PermissionError):
            continue
        if not target.startswith("socket:["):
            continue
        inode = target[8:-1]
        pid = fd_path.split("/")[2]
        mapping.setdefault(inode, []).append(pid)
    return mapping


def _read_proc_name(pid):
    try:
        with open(f"/proc/{pid}/comm", "r") as f:
            return f.read().strip()
    except (FileNotFoundError, PermissionError):
        return None


def resolve_processes(inode, pid_map):
    pids = pid_map.get(inode, [])
    names = []
    for pid in pids:
        name = _read_proc_name(pid)
        if name:
            label = f"{name} ({pid})"
            if label not in names:
                names.append(label)
    return ", ".join(names) if names else None


def docker_published_ports():
    """(proto, port) -> {container, image, container_port}. Empty dict (not
    an error) if docker isn't reachable — e.g. socket not mounted."""
    try:
        import docker
        client = docker.from_env()
        result = {}
        for c in client.containers.list():
            ports = (c.attrs.get("NetworkSettings", {}) or {}).get("Ports") or {}
            image_tags = []
            try:
                image_tags = c.image.tags
            except Exception:
                pass
            for container_port, bindings in ports.items():
                if not bindings:
                    continue
                proto = container_port.split("/")[-1] if "/" in container_port else "tcp"
                for b in bindings:
                    host_port = b.get("HostPort")
                    if not host_port:
                        continue
                    result[(proto, int(host_port))] = {
                        "container": c.name,
                        "image": image_tags[0] if image_tags else c.short_id,
                        "container_port": container_port,
                        "host_ip": b.get("HostIp") or "0.0.0.0",
                    }
        return result
    except Exception:
        return {}


def resolve_container_ip_for_port(proto, port):
    """Find the internal container IP + container-side port currently
    behind host port `port`/`proto`, for building a `ufw route allow`
    rule. Returns (ip, container_port) or None if nothing matches (the
    container isn't running, the port isn't actually published, port is a
    range, docker unreachable, etc.) — callers should treat None as
    "skip this rule", never crash on it."""
    try:
        import docker
        client = docker.from_env()
        for c in client.containers.list():
            attrs = c.attrs
            ports = (attrs.get("NetworkSettings", {}) or {}).get("Ports") or {}
            for container_port_proto, bindings in ports.items():
                if not bindings or "/" not in container_port_proto:
                    continue
                cport, cproto = container_port_proto.split("/", 1)
                if cproto != proto:
                    continue
                for b in bindings:
                    if str(b.get("HostPort")) != str(port):
                        continue
                    networks = (attrs.get("NetworkSettings", {}) or {}).get("Networks") or {}
                    for netinfo in networks.values():
                        ip = netinfo.get("IPAddress")
                        if ip:
                            return ip, cport
        return None
    except Exception:
        return None


def _is_loopback(addr):
    try:
        return ipaddress.ip_address(addr).is_loopback
    except ValueError:
        return False


# Scope answers "reachable from where". Broadest wins when different
# probes end up permitted via different rules.
_SCOPE_ORDER = {"none": 0, "lan": 1, "restricted": 2, "any": 3}
_GENERIC_LAN_PROBE = "192.168.1.123"
_GENERIC_PUBLIC_PROBE = "8.8.8.8"


def _classify_source(from_ip):
    """RFC1918/loopback/link-local/ULA source -> 'lan'; a specific public
    address/range -> 'restricted'; 'any'/unparsable -> 'any' (fail open, so
    an address we can't classify gets flagged rather than hidden)."""
    if from_ip in ("any", "", None):
        return "any"
    try:
        net = ipaddress.ip_network(from_ip, strict=False)
    except ValueError:
        return "any"
    if net.is_private or net.is_loopback or net.is_link_local:
        return "lan"
    return "restricted"


def _union_scope(scopes):
    if not scopes:
        return "none"
    return max(scopes, key=lambda s: _SCOPE_ORDER.get(s, 0))


def _rule_probe_addresses(rules, proto, port):
    """One representative address per distinct non-'any' source mentioned
    by a rule that could match this proto/port, so a rule scoped to a
    specific address/range gets tested against itself, not only against
    the two generic probes below."""
    addrs = set()
    for r in rules:
        if r.get("proto") not in ("any", proto):
            continue
        if not ufw.port_contains(r.get("port"), port):
            continue
        from_ip = r.get("from_ip")
        if from_ip and from_ip != "any":
            try:
                addrs.add(str(ipaddress.ip_network(from_ip, strict=False).network_address))
            except ValueError:
                continue
    return addrs


def compute_verdict_and_scope(entry, running_cfg):
    """Single source of truth for both the port's verdict (what ufw's
    ruleset actually decides) and its scope (reachable from where) —
    computed by walking the ruleset in order via ufw.evaluate() for a
    bounded set of representative source addresses, the same engine Test
    Connection uses for one concrete address.

    This replaced an earlier version that just scanned for *any* allow
    rule mentioning the port, ignoring rule order and deny rules entirely.
    That meant a blanket `deny` placed before a more specific `allow` for
    the same port — which really means the port is blocked for everyone,
    the allow is dead — was reported as open. Probing through the real
    order-aware evaluator instead of pattern-scanning the rule list catches
    that. It can still miss a rule scoped to a private range this tool
    didn't think to probe (see README) — Test Connection with the exact
    address in question is the precise answer; this is the map's best
    general-case summary."""
    if _is_loopback(entry["addr"]):
        return "loopback", "loopback"

    if entry.get("docker"):
        host_ip = entry["docker"].get("host_ip") or "0.0.0.0"
        if _is_loopback(host_ip):
            return "loopback", "loopback"
        return "docker-bypass", "any"

    policies = running_cfg.get("policies", {})
    rules = running_cfg.get("rules", [])
    proto, port = entry["proto"], entry["port"]

    probes = {_GENERIC_LAN_PROBE, _GENERIC_PUBLIC_PROBE} | _rule_probe_addresses(rules, proto, port)

    scopes = []
    any_allowed = False
    matched_nondefault = False
    for probe in probes:
        result = ufw.evaluate(rules, policies, "in", proto, port, probe)
        if result["action"] not in ("allow", "limit"):
            continue
        any_allowed = True
        if result["rule"] is not None:
            matched_nondefault = True
            scopes.append(_classify_source(result["rule"].get("from_ip")))
        else:
            scopes.append("any")  # default-policy allow: no source rule restricts it at all

    if not any_allowed:
        return "blocked", "none"

    verdict = "allowed-rule" if matched_nondefault else "allowed-default"
    return verdict, _union_scope(scopes)


def docker_user_chain_status():
    """Heuristic check for whether a ufw-docker-style mitigation looks like
    it's been applied to the DOCKER-USER chain (e.g. via the well-known
    https://github.com/chaifeng/ufw-docker fix). Docker itself creates this
    chain with exactly one rule — `-A DOCKER-USER -j RETURN` — as a no-op
    placeholder; anything beyond that was added by something else.

    This can only ever be a heuristic: it tells you *something* was added,
    not that it correctly covers any given port. Returns True/False, or
    None if it couldn't be determined at all (no permission, no iptables,
    a pure-nftables host with no compat layer, chain doesn't exist, etc.) —
    callers should treat None as "unknown", not as "no mitigation"."""
    try:
        res = subprocess.run(["iptables", "-S", "DOCKER-USER"],
                              capture_output=True, text=True, timeout=5)
    except Exception:
        return None
    if res.returncode != 0:
        return None
    rule_lines = [l for l in res.stdout.splitlines() if l.strip().startswith("-A ")]
    if not rule_lines:
        return None
    default_only = len(rule_lines) == 1 and rule_lines[0].strip() == "-A DOCKER-USER -j RETURN"
    return not default_only


def build_portmap(running_cfg):
    sockets = list_listening_sockets()
    pid_map = build_inode_pid_map()
    dports = docker_published_ports()

    entries = []
    for s in sockets:
        entry = dict(s)
        entry["process"] = resolve_processes(s["inode"], pid_map)
        entry["docker"] = dports.get((s["proto"], s["port"]))
        entry["verdict"], entry["scope"] = compute_verdict_and_scope(entry, running_cfg)
        entries.append(entry)

    entries.sort(key=lambda e: (e["port"], e["proto"], e["addr"]))

    return {
        "entries": entries,
        "docker_available": bool(dports) or _docker_reachable(),
        "pid_visibility": bool(pid_map),
        "docker_user_chain_customized": docker_user_chain_status() if bool(dports) else None,
    }


def _docker_reachable():
    try:
        import docker
        docker.from_env().ping()
        return True
    except Exception:
        return False

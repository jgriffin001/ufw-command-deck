import json
import os
import threading

from config import DATA_DIR

_lock = threading.Lock()


def _path(name):
    return os.path.join(DATA_DIR, name)


def ensure_data_dir():
    os.makedirs(DATA_DIR, exist_ok=True)


def load(name, default=None):
    ensure_data_dir()
    p = _path(name)
    if not os.path.exists(p):
        return default
    with _lock:
        with open(p, "r") as f:
            return json.load(f)


def save(name, data):
    ensure_data_dir()
    p = _path(name)
    tmp = p + ".tmp"
    with _lock:
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, p)


def exists(name):
    return os.path.exists(_path(name))

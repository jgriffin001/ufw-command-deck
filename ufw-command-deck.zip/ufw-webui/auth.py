import secrets
import time
from functools import wraps

from flask import redirect, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

import config
import storage

# in-memory brute-force throttle: ip -> (fail_count, locked_until_epoch)
_fail_tracker = {}


def get_or_create_password():
    """Ensure a password hash exists. Returns the plaintext password only if
    one was freshly generated (so it can be logged once), else None."""
    if config.WEBUI_PASSWORD:
        storage.save("auth.json", {
            "password_hash": generate_password_hash(config.WEBUI_PASSWORD),
            "source": "env",
        })
        return None

    existing = storage.load("auth.json")
    if existing and existing.get("password_hash"):
        return None

    generated = secrets.token_urlsafe(12)
    storage.save("auth.json", {
        "password_hash": generate_password_hash(generated),
        "source": "generated",
    })
    return generated


def check_password(pw):
    auth = storage.load("auth.json")
    if not auth:
        return False
    return check_password_hash(auth["password_hash"], pw)


def is_locked(ip):
    count, locked_until = _fail_tracker.get(ip, (0, 0))
    return locked_until and time.time() < locked_until


def record_fail(ip):
    count, _ = _fail_tracker.get(ip, (0, 0))
    count += 1
    locked_until = time.time() + 30 if count >= 5 else 0
    _fail_tracker[ip] = (count, locked_until)


def record_success(ip):
    _fail_tracker.pop(ip, None)


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("authed"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

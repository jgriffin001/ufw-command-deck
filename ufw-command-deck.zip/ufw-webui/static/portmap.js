/* Left-to-right data flow: NET/LAN (source column) -> HOST (ufw gate) ->
 * [DOCKER -> CONTAINER, only for docker-published ports] -> each listening
 * port. Every connection is a polyline through named node ids, redrawn
 * from live node positions — which makes zoom/pan (a transform on the
 * whole viewport group), per-node dragging (move one node, redraw only the
 * polylines that reference it), and collapsing a junction (hide everything
 * downstream of it, truncate the lines that feed into it) all cheap and
 * consistent with each other. No physics sim: layout is fixed on each
 * render(), and drag positions reset on the next render() (a fresh scan or
 * a collapse toggle) — they're a manual decluttering aid for *this* view,
 * not a saved layout.
 */
const PortMap = (() => {
  const SVG_NS = "http://www.w3.org/2000/svg";

  const COLORS = {
    "allowed-rule": "#39ff8a",
    "blocked": "#2ee6ff",
    "allowed-default": "#ffb32e",
    "loopback": "#5f8494",
    "docker-bypass": "#ff3b5c",
  };

  const LABELS = {
    "allowed-rule": "ALLOWED (by rule)",
    "blocked": "BLOCKED (default deny, no rule)",
    "allowed-default": "ALLOWED (default policy)",
    "loopback": "LOOPBACK ONLY — not exposed",
    "docker-bypass": "DOCKER — bypasses ufw",
  };

  const SCOPE_LABELS = {
    "loopback": "not reachable off-box",
    "none": "not reachable from the network",
    "lan": "reachable from LAN only",
    "restricted": "reachable from a specific external address only",
    "any": "reachable from ANY source — potentially internet-exposed if your router forwards it",
  };

  const SCOPE_RANK = { any: 0, restricted: 1, lan: 2, none: 3, loopback: 4 };
  const ZOOM_MIN = 0.35, ZOOM_MAX = 3;
  const CANVAS_W = 900, CANVAS_H = 620;

  // Persisted at module scope so re-rendering (a fresh scan, or a collapse
  // toggle re-render) keeps whatever view/collapse state the user set up.
  // Node drag positions are NOT persisted — those live in a per-render
  // closure and reset whenever render() runs again.
  const view = { zoom: 1, panX: 0, panY: 0 };
  const collapsed = new Set(); // junction node ids: "host", "docker", "container:<name>"
  let currentViewportG = null;
  let lastEntries = null, lastOnSelect = null, lastSvgEl = null;

  function sortForDisplay(entries) {
    return [...entries].sort((a, b) => {
      const r = (SCOPE_RANK[a.scope] ?? 9) - (SCOPE_RANK[b.scope] ?? 9);
      if (r !== 0) return r;
      return a.port - b.port;
    });
  }

  function clampZoom(z) {
    return Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, z));
  }

  function applyView() {
    if (currentViewportG) {
      currentViewportG.setAttribute("transform", `translate(${view.panX},${view.panY}) scale(${view.zoom})`);
    }
  }

  // rx,ry: the root-canvas point that should stay under the cursor/center
  // while the zoom level changes around it.
  function zoomAt(factor, rx, ry) {
    const newZoom = clampZoom(view.zoom * factor);
    const ratio = newZoom / view.zoom;
    view.panX = rx - ratio * (rx - view.panX);
    view.panY = ry - ratio * (ry - view.panY);
    view.zoom = newZoom;
    applyView();
  }

  function zoomIn() { zoomAt(1.25, CANVAS_W / 2, CANVAS_H / 2); }
  function zoomOut() { zoomAt(0.8, CANVAS_W / 2, CANVAS_H / 2); }
  function resetView() {
    view.zoom = 1; view.panX = 0; view.panY = 0;
    applyView();
  }

  // Screen (client) coords -> the coordinate space `el` defines for its
  // children, using the element's own accumulated screen transform. Works
  // regardless of the current zoom/pan, since getScreenCTM already folds
  // in every ancestor transform up to the document root.
  function toLocal(el, clientX, clientY) {
    const svg = el.ownerSVGElement || el;
    const pt = svg.createSVGPoint();
    pt.x = clientX; pt.y = clientY;
    const ctm = el.getScreenCTM();
    if (!ctm) return { x: 0, y: 0 };
    const p = pt.matrixTransform(ctm.inverse());
    return { x: p.x, y: p.y };
  }

  function emphasizeSegs(segs, on) {
    segs.forEach(({ el, restOpacity, restWidth }) => {
      el.setAttribute("stroke-opacity", on ? 0.9 : restOpacity);
      el.setAttribute("stroke-width", on ? restWidth + 1.5 : restWidth);
    });
  }

  // A chain like [zone, host, docker, container:X, port] gets cut short at
  // the first node in it that's currently collapsed — so the line still
  // visibly arrives *at* the collapsed junction, it just doesn't continue
  // past it. Returns null if that leaves fewer than 2 points to draw.
  function effectiveChain(chain) {
    for (let i = 0; i < chain.length; i++) {
      if (collapsed.has(chain[i])) {
        return i + 1 >= 2 ? chain.slice(0, i + 1) : null;
      }
    }
    return chain;
  }

  function ancestorsOf(id) {
    if (id === "docker") return ["host"];
    if (id.startsWith("container:")) return ["docker", "host"];
    return []; // ports get their ancestors computed inline (depends on the entry)
  }

  function isHiddenByCollapse(ancestors) {
    return ancestors.some(a => collapsed.has(a));
  }

  function render(svgEl, entriesIn, onSelect) {
    lastEntries = entriesIn; lastOnSelect = onSelect; lastSvgEl = svgEl;

    while (svgEl.firstChild) svgEl.removeChild(svgEl.firstChild);
    const entries = sortForDisplay(entriesIn);
    const n = entries.length;
    const rowHeight = 32;
    const marginY = 50;

    const containerYSum = {}, containerCount = {};
    const dockerPortCount = { total: 0 };
    entries.forEach((e, i) => {
      if (e.docker) {
        const y = marginY + i * rowHeight + rowHeight / 2;
        const name = e.docker.container;
        containerYSum[name] = (containerYSum[name] || 0) + y;
        containerCount[name] = (containerCount[name] || 0) + 1;
        dockerPortCount.total++;
      }
    });
    const containerNames = Object.keys(containerYSum);
    const hasDocker = containerNames.length > 0;

    const width = hasDocker ? 1080 : CANVAS_W;
    const height = CANVAS_H;

    svgEl.setAttribute("viewBox", `0 0 ${CANVAS_W} ${CANVAS_H}`);
    svgEl.setAttribute("width", "100%");
    svgEl.setAttribute("height", "100%");
    svgEl.setAttribute("preserveAspectRatio", "xMidYMid meet");

    const zoneX = 60;
    const hostX = hasDocker ? width * 0.17 : width * 0.34;
    const dockerX = width * 0.34;
    const containerX = width * 0.51;
    const portX = hasDocker ? width * 0.76 : width * 0.58;
    const hostY = height / 2;
    const lanY = hostY; // single entry point, level with the gate it feeds
    const anyExposedCount = entries.filter(e => e.scope === "any").length;

    const defs = document.createElementNS(SVG_NS, "defs");
    const glow = document.createElementNS(SVG_NS, "filter");
    glow.setAttribute("id", "pm-glow");
    glow.setAttribute("x", "-100%"); glow.setAttribute("y", "-100%");
    glow.setAttribute("width", "300%"); glow.setAttribute("height", "300%");
    glow.innerHTML = '<feGaussianBlur stdDeviation="3.5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>';
    defs.appendChild(glow);
    svgEl.appendChild(defs);

    const viewportG = document.createElementNS(SVG_NS, "g");
    svgEl.appendChild(viewportG);
    currentViewportG = viewportG;
    applyView();

    const edgeLayer = document.createElementNS(SVG_NS, "g");
    const nodeLayer = document.createElementNS(SVG_NS, "g");
    viewportG.appendChild(edgeLayer);
    viewportG.appendChild(nodeLayer);

    // ---- live node positions: single source of truth for drag, edges,
    // and collapse. Node id scheme: zone:lan (the sole network entry
    // point), host, docker, container:<name>, port:<proto>:<addr>:<port> ----
    const positions = {
      "zone:lan": { x: zoneX, y: lanY },
      "host": { x: hostX, y: hostY },
    };
    if (hasDocker) positions["docker"] = { x: dockerX, y: hostY };
    const containerYAvg = {};
    containerNames.forEach(name => { containerYAvg[name] = containerYSum[name] / containerCount[name]; });
    containerNames.forEach(name => { positions[`container:${name}`] = { x: containerX, y: containerYAvg[name] }; });

    const portId = (e) => `port:${e.proto}:${e.addr}:${e.port}`;
    entries.forEach((e, i) => {
      positions[portId(e)] = { x: portX, y: marginY + i * rowHeight + rowHeight / 2 };
    });

    function portAncestors(e) {
      if (!e.docker) return ["host"];
      return [`container:${e.docker.container}`, "docker", "host"];
    }

    // ---- build edge definitions as chains of node ids (topology only —
    // actual coordinates are looked up live from `positions` on every draw) ----
    const edgeDefs = [];
    entries.forEach(e => {
      const reachable = e.scope === "lan" || e.scope === "restricted" || e.scope === "any";
      const mid = e.docker ? ["docker", `container:${e.docker.container}`] : [];
      const pid = portId(e);

      if (reachable) {
        let style;
        if (e.scope === "any") style = { stroke: "#ff3b5c", opacity: 0.6, width: 2 };
        else if (e.scope === "restricted") style = { stroke: "#ffb32e", opacity: 0.4, width: 1, dash: "2 3" };
        else style = { stroke: "#2ee6ff", opacity: 0.32, width: 1.2 };
        edgeDefs.push({ chain: ["zone:lan", "host", ...mid, pid], portEntry: e, style });
      } else {
        const color = COLORS[e.verdict] || "#5f8494";
        const risky = e.verdict === "docker-bypass";
        edgeDefs.push({ chain: ["host", ...mid, pid], portEntry: e,
          style: { stroke: color, opacity: 0.35, width: risky ? 1.5 : 1, dash: (risky || e.scope === "loopback") ? "3 3" : null } });
      }
    });

    // ---- draw edges as polylines (only the ones collapse leaves visible) ----
    const edgeEls = [];
    edgeDefs.forEach(def => {
      const chain = effectiveChain(def.chain);
      if (!chain) return; // fully swallowed by a collapse right at its own start
      const pl = document.createElementNS(SVG_NS, "polyline");
      pl.setAttribute("fill", "none");
      pl.setAttribute("stroke", def.style.stroke);
      pl.setAttribute("stroke-opacity", def.style.opacity);
      pl.setAttribute("stroke-width", def.style.width);
      if (def.style.dash) pl.setAttribute("stroke-dasharray", def.style.dash);
      edgeLayer.appendChild(pl);
      edgeEls.push({ def, chain, el: pl, restOpacity: def.style.opacity, restWidth: def.style.width });
    });

    function redrawEdge(edge) {
      const pts = edge.chain.map(id => positions[id]).map(p => `${p.x},${p.y}`).join(" ");
      edge.el.setAttribute("points", pts);
    }
    edgeEls.forEach(redrawEdge);

    const edgesByPort = {};
    entries.forEach(e => { edgesByPort[portId(e)] = edgeEls.filter(edge => edge.def.portEntry === e); });
    const edgesByContainer = {};
    containerNames.forEach(name => {
      edgesByContainer[name] = edgeEls.filter(edge => edge.chain.includes(`container:${name}`));
    });
    const edgesByNodeId = {};
    Object.keys(positions).forEach(id => {
      edgesByNodeId[id] = edgeEls.filter(edge => edge.chain.includes(id));
    });

    function makeDraggable(g, id) {
      let dragged = false;
      g.addEventListener("mousedown", (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
        dragged = false;
        const start = toLocal(viewportG, ev.clientX, ev.clientY);
        const startPos = { ...positions[id] };
        const move = (mv) => {
          const cur = toLocal(viewportG, mv.clientX, mv.clientY);
          const dx = cur.x - start.x, dy = cur.y - start.y;
          if (Math.abs(dx) > 2 || Math.abs(dy) > 2) dragged = true;
          positions[id] = { x: startPos.x + dx, y: startPos.y + dy };
          g.setAttribute("transform", `translate(${positions[id].x},${positions[id].y})`);
          edgesByNodeId[id].forEach(redrawEdge);
        };
        const up = () => {
          window.removeEventListener("mousemove", move);
          window.removeEventListener("mouseup", up);
        };
        window.addEventListener("mousemove", move);
        window.addEventListener("mouseup", up);
      });
      g.wasDragged = () => dragged;
    }

    function toggleCollapse(id) {
      if (collapsed.has(id)) collapsed.delete(id); else collapsed.add(id);
      render(lastSvgEl, lastEntries, lastOnSelect);
    }

    function junctionNode(id, r, color, baseLabel, cls, pulse, hiddenCount) {
      const pos = positions[id];
      const isCollapsed = collapsed.has(id);
      const g = document.createElementNS(SVG_NS, "g");
      g.setAttribute("transform", `translate(${pos.x},${pos.y})`);
      g.style.cursor = "pointer";

      const circle = document.createElementNS(SVG_NS, "circle");
      circle.setAttribute("r", r);
      circle.setAttribute("fill", "#0a0f14");
      circle.setAttribute("stroke", color);
      circle.setAttribute("stroke-width", "2");
      circle.setAttribute("filter", "url(#pm-glow)");
      if (isCollapsed) circle.setAttribute("stroke-dasharray", "4 3");
      if (pulse) circle.setAttribute("class", "pm-pulse");
      g.appendChild(circle);

      const text = document.createElementNS(SVG_NS, "text");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("y", 4);
      text.setAttribute("class", cls);
      text.setAttribute("fill", color);
      text.textContent = baseLabel;
      g.appendChild(text);

      if (isCollapsed && hiddenCount > 0) {
        const badge = document.createElementNS(SVG_NS, "text");
        badge.setAttribute("text-anchor", "middle");
        badge.setAttribute("y", r + 14);
        badge.setAttribute("class", "pm-collapse-badge");
        badge.textContent = `+${hiddenCount} hidden`;
        g.appendChild(badge);
      }

      const title = document.createElementNS(SVG_NS, "title");
      title.textContent = isCollapsed
        ? `${baseLabel} — collapsed (${hiddenCount} hidden). Click to expand.`
        : `${baseLabel} — click to collapse everything behind it.`;
      g.appendChild(title);

      nodeLayer.appendChild(g);
      makeDraggable(g, id);
      g.addEventListener("click", () => { if (!g.wasDragged()) toggleCollapse(id); });
      return g;
    }

    junctionNode("host", 24, "#2ee6ff", "UFW", "pm-host-label", false, entries.length);

    if (hasDocker && !isHiddenByCollapse(ancestorsOf("docker"))) {
      junctionNode("docker", 22, "#ff2ea6", "DOCKER", "pm-docker-label", false, dockerPortCount.total);
    }

    containerNames.forEach(name => {
      if (isHiddenByCollapse(ancestorsOf(`container:${name}`))) return;
      const count = entries.filter(e => e.docker && e.docker.container === name).length;
      const g = junctionNode(`container:${name}`, 16, "#ffb32e",
        name.length > 10 ? name.slice(0, 9) + "…" : name, "pm-container-label", false, count);
      g.addEventListener("mouseenter", () => emphasizeSegs(edgesByContainer[name], true));
      g.addEventListener("mouseleave", () => emphasizeSegs(edgesByContainer[name], false));
    });

    // The zone is the sole network entry point — always visible, never
    // collapsible. It pulses red the moment anything has an ANY-scope
    // edge (a candidate for internet exposure), calm cyan otherwise; the
    // per-edge color is what actually says LAN-only vs restricted vs any.
    function zoneNode(id, color, label, pulse, titleText) {
      const pos = positions[id];
      const g = document.createElementNS(SVG_NS, "g");
      g.setAttribute("transform", `translate(${pos.x},${pos.y})`);
      g.style.cursor = "grab";
      const circle = document.createElementNS(SVG_NS, "circle");
      circle.setAttribute("r", 28);
      circle.setAttribute("fill", "#0a0f14");
      circle.setAttribute("stroke", color);
      circle.setAttribute("stroke-width", "2");
      circle.setAttribute("filter", "url(#pm-glow)");
      if (pulse) circle.setAttribute("class", "pm-pulse");
      g.appendChild(circle);
      const text = document.createElementNS(SVG_NS, "text");
      text.setAttribute("text-anchor", "middle");
      text.setAttribute("y", 4);
      text.setAttribute("class", "pm-zone-label");
      text.setAttribute("fill", color);
      text.textContent = label;
      g.appendChild(text);
      if (titleText) {
        const t = document.createElementNS(SVG_NS, "title");
        t.textContent = titleText;
        g.appendChild(t);
      }
      nodeLayer.appendChild(g);
      makeDraggable(g, id);
      return g;
    }
    zoneNode("zone:lan", anyExposedCount > 0 ? "#ff3b5c" : "#2ee6ff", "LAN", anyExposedCount > 0,
      "Network entry point. Blue edges = LAN-only. Amber dashed = one specific external address. Red = any source (potentially internet-exposed if your router forwards it).");

    entries.forEach(e => {
      if (isHiddenByCollapse(portAncestors(e))) return;
      const pid = portId(e);
      const pos = positions[pid];
      const color = COLORS[e.verdict] || "#5f8494";
      const risky = e.verdict === "docker-bypass";

      const g = document.createElementNS(SVG_NS, "g");
      g.setAttribute("transform", `translate(${pos.x},${pos.y})`);
      g.style.cursor = "grab";

      const circle = document.createElementNS(SVG_NS, "circle");
      circle.setAttribute("r", 9);
      circle.setAttribute("fill", color);
      circle.setAttribute("fill-opacity", "0.85");
      circle.setAttribute("stroke", color);
      if (risky || e.scope === "any") circle.setAttribute("filter", "url(#pm-glow)");
      g.appendChild(circle);

      if (e.is_new) {
        const ring = document.createElementNS(SVG_NS, "circle");
        ring.setAttribute("r", 14);
        ring.setAttribute("fill", "none");
        ring.setAttribute("stroke", "#ff2ea6");
        ring.setAttribute("stroke-width", "1.5");
        ring.setAttribute("class", "pm-pulse");
        g.appendChild(ring);
      }

      const title = document.createElementNS(SVG_NS, "title");
      title.textContent =
        `${e.port}/${e.proto} on ${e.addr}\n${LABELS[e.verdict] || e.verdict}\n${SCOPE_LABELS[e.scope] || e.scope}` +
        (e.process ? `\nprocess: ${e.process}` : "") +
        (e.docker ? `\ncontainer: ${e.docker.container}` : "") +
        (e.is_new ? `\n🆕 new since your last scan` : "");
      g.appendChild(title);

      const who = e.docker ? null : (e.process ? e.process.split(" (")[0] : "");
      let labelText = `${e.port}/${e.proto}`;
      if (who) labelText += `  ${who}`;
      if (labelText.length > 30) labelText = labelText.slice(0, 29) + "…";
      if (e.is_new) labelText += " 🆕";

      const label = document.createElementNS(SVG_NS, "text");
      label.setAttribute("class", "pm-node-label");
      label.setAttribute("x", 16);
      label.setAttribute("y", 4);
      label.textContent = labelText;
      g.appendChild(label);

      g.addEventListener("mouseenter", () => emphasizeSegs(edgesByPort[pid], true));
      g.addEventListener("mouseleave", () => emphasizeSegs(edgesByPort[pid], false));
      g.addEventListener("click", () => { if (!g.wasDragged()) onSelect && onSelect(e); });
      nodeLayer.appendChild(g);
      makeDraggable(g, pid);
    });

    // ---- background pan (drag empty canvas) ----
    svgEl.onmousedown = (ev) => {
      if (ev.target !== svgEl) return; // a node/edge click already stopped propagation
      const startClient = { x: ev.clientX, y: ev.clientY };
      const startPan = { x: view.panX, y: view.panY };
      svgEl.style.cursor = "grabbing";
      const move = (mv) => {
        view.panX = startPan.x + (mv.clientX - startClient.x);
        view.panY = startPan.y + (mv.clientY - startClient.y);
        applyView();
      };
      const up = () => {
        svgEl.style.cursor = "";
        window.removeEventListener("mousemove", move);
        window.removeEventListener("mouseup", up);
      };
      window.addEventListener("mousemove", move);
      window.addEventListener("mouseup", up);
    };

    svgEl.onwheel = (ev) => {
      ev.preventDefault();
      const cursor = toLocal(svgEl, ev.clientX, ev.clientY);
      zoomAt(ev.deltaY < 0 ? 1.12 : 0.89, cursor.x, cursor.y);
    };
  }

  return { render, zoomIn, zoomOut, resetView, LABELS, SCOPE_LABELS };
})();

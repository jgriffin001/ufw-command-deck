const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

let pollTimer = null;

async function api(path, opts) {
  const res = await fetch(path, Object.assign({
    headers: { "Content-Type": "application/json" },
  }, opts));
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(body.error || res.statusText);
    err.body = body;
    throw err;
  }
  return body;
}

function toast(msg, kind) {
  const stack = $("#toast-stack");
  const el = document.createElement("div");
  el.className = "toast" + (kind ? " " + kind : "");
  el.textContent = msg;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

function fmtRule(r) {
  return r;
}

let draggedRowId = null;

function renderRuleRowEditable(rule) {
  const tr = document.createElement("tr");
  tr.dataset.id = rule.id;
  tr.draggable = true;
  tr.addEventListener("dragstart", (ev) => {
    draggedRowId = rule.id;
    tr.classList.add("dragging");
    ev.dataTransfer.effectAllowed = "move";
  });
  tr.addEventListener("dragend", () => {
    tr.classList.remove("dragging");
    draggedRowId = null;
  });

  const tdHandle = document.createElement("td");
  tdHandle.className = "drag-handle";
  tdHandle.textContent = "⋮⋮";
  tdHandle.title = "Drag to reorder — rule order matters, ufw uses the first match";
  tr.appendChild(tdHandle);

  const tdCheck = document.createElement("td");
  const cb = document.createElement("input");
  cb.type = "checkbox";
  cb.checked = rule.enabled !== false;
  cb.addEventListener("change", () => updateRule(rule.id, { enabled: cb.checked }));
  tdCheck.appendChild(cb);
  tr.appendChild(tdCheck);

  function selectCell(field, options, value) {
    const td = document.createElement("td");
    const sel = document.createElement("select");
    options.forEach(o => {
      const opt = document.createElement("option");
      opt.value = o;
      opt.textContent = o.toUpperCase();
      if (o === value) opt.selected = true;
      sel.appendChild(opt);
    });
    sel.addEventListener("change", () => updateRule(rule.id, { [field]: sel.value }));
    td.appendChild(sel);
    return td;
  }

  function inputCell(field, value, placeholder) {
    const td = document.createElement("td");
    const inp = document.createElement("input");
    inp.value = value || "";
    if (placeholder) inp.placeholder = placeholder;
    inp.addEventListener("change", () => updateRule(rule.id, { [field]: inp.value }));
    td.appendChild(inp);
    return td;
  }

  tr.appendChild(selectCell("action", ["allow", "deny", "reject", "limit"], rule.action));
  tr.appendChild(selectCell("direction", ["in", "out"], rule.direction));
  tr.appendChild(selectCell("proto", ["any", "tcp", "udp"], rule.proto));
  tr.appendChild(inputCell("port", rule.port, "any"));
  tr.appendChild(inputCell("from_ip", rule.from_ip, "any"));
  tr.appendChild(inputCell("to_ip", rule.to_ip, "any"));
  tr.appendChild(inputCell("comment", rule.comment, ""));

  const tdDocker = document.createElement("td");
  const dockerCb = document.createElement("input");
  dockerCb.type = "checkbox";
  dockerCb.checked = !!rule.docker_forward;
  dockerCb.title = "Also allow through Docker's DOCKER-USER chain for a published container port matching this port/proto/source";
  dockerCb.addEventListener("change", () => updateRule(rule.id, { docker_forward: dockerCb.checked }));
  tdDocker.appendChild(dockerCb);
  tr.appendChild(tdDocker);

  const tdDel = document.createElement("td");
  const delBtn = document.createElement("button");
  delBtn.className = "row-delete-btn";
  delBtn.textContent = "✕";
  delBtn.title = "Delete rule";
  delBtn.addEventListener("click", () => deleteRule(rule.id));
  tdDel.appendChild(delBtn);
  tr.appendChild(tdDel);

  return tr;
}

function computeReorderedIds(draggedId, targetId, insertBefore) {
  const ids = $$("#candidate-rows tr").map(tr => tr.dataset.id);
  const fromIdx = ids.indexOf(draggedId);
  if (fromIdx === -1) return ids;
  ids.splice(fromIdx, 1);
  let toIdx = ids.indexOf(targetId);
  if (toIdx === -1) return ids;
  if (!insertBefore) toIdx += 1;
  ids.splice(toIdx, 0, draggedId);
  return ids;
}

function wireCandidateDragReorder() {
  const tbody = $("#candidate-rows");

  tbody.addEventListener("dragover", (ev) => {
    ev.preventDefault();
    const targetRow = ev.target.closest("tr");
    if (!targetRow || targetRow.dataset.id === draggedRowId) return;
    $$("#candidate-rows tr").forEach(tr => tr.classList.remove("drag-over-top", "drag-over-bottom"));
    const rect = targetRow.getBoundingClientRect();
    const before = (ev.clientY - rect.top) < rect.height / 2;
    targetRow.classList.add(before ? "drag-over-top" : "drag-over-bottom");
  });

  tbody.addEventListener("drop", async (ev) => {
    ev.preventDefault();
    const targetRow = ev.target.closest("tr");
    $$("#candidate-rows tr").forEach(tr => tr.classList.remove("drag-over-top", "drag-over-bottom"));
    if (!targetRow || !draggedRowId || targetRow.dataset.id === draggedRowId) return;
    const rect = targetRow.getBoundingClientRect();
    const before = (ev.clientY - rect.top) < rect.height / 2;
    const order = computeReorderedIds(draggedRowId, targetRow.dataset.id, before);
    try {
      await api("/api/candidate/reorder", { method: "POST", body: JSON.stringify({ order }) });
      await refreshState();
      toast("Rule order updated.");
    } catch (e) {
      toast(e.message, "error");
    }
  });
}

function renderRuleRowReadonly(rule) {
  const tr = document.createElement("tr");
  const cells = [
    { text: rule.action ? rule.action.toUpperCase() : "?", cls: "tag-" + (rule.action || "") },
    { text: (rule.direction || "in").toUpperCase() },
    { text: (rule.proto || "any").toUpperCase() },
    { text: rule.port || "any" },
    { text: rule.from_ip || "any" },
    { text: rule.to_ip || "any" },
    { text: rule.comment || "" },
    { text: rule.docker_forward ? "🐳" : "—", cls: rule.docker_forward ? "tag-allow" : "" },
  ];
  cells.forEach(c => {
    const td = document.createElement("td");
    td.textContent = c.text;
    if (c.cls) td.className = c.cls;
    tr.appendChild(td);
  });
  if (!rule.enabled && rule.enabled !== undefined) tr.style.opacity = "0.4";
  return tr;
}

function renderPoliciesEditable(cfg) {
  const row = $("#candidate-policies");
  $$('select[data-policy]', row).forEach(sel => {
    const key = sel.dataset.policy;
    const val = key === "logging" ? cfg.logging : cfg.policies[key];
    sel.value = val;
    sel.onchange = () => {
      if (key === "logging") {
        api("/api/candidate/policies", { method: "POST", body: JSON.stringify({ logging: sel.value }) })
          .then(refreshState).catch(e => toast(e.message, "error"));
      } else {
        api("/api/candidate/policies", { method: "POST", body: JSON.stringify({ policies: { [key]: sel.value } }) })
          .then(refreshState).catch(e => toast(e.message, "error"));
      }
    };
  });
}

function renderPoliciesReadonly(cfg) {
  const row = $("#running-policies");
  row.innerHTML = "";
  const items = [
    ["INCOMING", cfg.policies.incoming],
    ["OUTGOING", cfg.policies.outgoing],
    ["ROUTED", cfg.policies.routed],
    ["LOGGING", cfg.logging],
  ];
  items.forEach(([label, val]) => {
    const div = document.createElement("div");
    div.className = "policy-field";
    div.innerHTML = `<label>${label}</label><select disabled><option selected>${(val || "?").toUpperCase()}</option></select>`;
    row.appendChild(div);
  });
}

async function refreshState() {
  const state = await api("/api/state");
  const { running, candidate, pending_commit } = state;

  renderPoliciesEditable(candidate);
  const candBody = $("#candidate-rows");
  candBody.innerHTML = "";
  candidate.rules.forEach(r => candBody.appendChild(renderRuleRowEditable(r)));
  applyTableFilter("candidate-table");

  renderPoliciesReadonly(running);
  const runBody = $("#running-rows");
  runBody.innerHTML = "";
  running.rules.forEach(r => runBody.appendChild(renderRuleRowReadonly(r)));
  applyTableFilter("running-table");

  const committedAt = running.committed_at
    ? new Date(running.committed_at * 1000).toLocaleString()
    : "(imported, never committed via this tool)";
  $("#running-committed-at").textContent = committedAt;

  updateStatusPill(running);
  updateCommitBar(pending_commit);

  return state;
}

function updateStatusPill(running) {
  const pill = $("#ufw-status-pill");
  const incoming = running.policies.incoming;
  if (incoming === "deny" || incoming === "reject") {
    pill.textContent = "ENFORCING";
    pill.className = "pill pill-active";
  } else {
    pill.textContent = "PERMISSIVE";
    pill.className = "pill pill-inactive";
  }
}

let countdownInterval = null;

function updateCommitBar(pending) {
  const bar = $("#commit-bar");
  if (pending && pending.active) {
    bar.classList.remove("hidden");
    let secondsLeft = pending.seconds_left;
    $("#commit-countdown").textContent = secondsLeft;
    if (countdownInterval) clearInterval(countdownInterval);
    countdownInterval = setInterval(() => {
      secondsLeft -= 1;
      if (secondsLeft <= 0) {
        clearInterval(countdownInterval);
        refreshState();
        return;
      }
      $("#commit-countdown").textContent = secondsLeft;
    }, 1000);
  } else {
    bar.classList.add("hidden");
    if (countdownInterval) clearInterval(countdownInterval);
  }
}

async function updateRule(id, patch) {
  try {
    await api(`/api/candidate/rules/${id}`, { method: "PUT", body: JSON.stringify(patch) });
  } catch (e) {
    toast(e.message, "error");
  }
}

async function deleteRule(id) {
  try {
    await api(`/api/candidate/rules/${id}`, { method: "DELETE" });
    await refreshState();
    toast("Rule removed from candidate.");
  } catch (e) {
    toast(e.message, "error");
  }
}

function renderValidationReport(result) {
  const body = $("#validate-body");
  body.innerHTML = "";

  const errSec = document.createElement("div");
  errSec.className = "report-section errors";
  if (result.errors.length) {
    errSec.innerHTML = `<h4>✕ ERRORS (blocking)</h4><ul>${result.errors.map(e => `<li>${escapeHtml(e)}</li>`).join("")}</ul>`;
  } else {
    errSec.innerHTML = `<h4 class="report-ok">✓ NO ERRORS</h4>`;
  }
  body.appendChild(errSec);

  const warnSec = document.createElement("div");
  warnSec.className = "report-section warnings";
  if (result.warnings.length) {
    warnSec.innerHTML = `<h4>⚠ WARNINGS</h4><ul>${result.warnings.map(w => `<li>${escapeHtml(w)}</li>`).join("")}</ul>`;
  } else {
    warnSec.innerHTML = `<h4 class="report-ok">✓ NO WARNINGS</h4>`;
  }
  body.appendChild(warnSec);

  const diff = result.diff;
  const diffSec = document.createElement("div");
  diffSec.className = "report-section diff";
  let diffHtml = `<h4>DIFF vs RUNNING</h4><ul>`;
  if (diff.policy_changed) diffHtml += `<li class="diff-add">+ default policies changed</li>`;
  if (diff.logging_changed) diffHtml += `<li class="diff-add">+ logging level changed</li>`;
  diff.added.forEach(r => {
    diffHtml += `<li class="diff-add">+ ${r.action} ${r.direction} ${r.proto} port ${r.port || "any"} from ${r.from_ip} to ${r.to_ip}</li>`;
  });
  diff.removed.forEach(r => {
    diffHtml += `<li class="diff-remove">- ${r.action} ${r.direction} ${r.proto} port ${r.port || "any"} from ${r.from_ip} to ${r.to_ip}</li>`;
  });
  if (!diff.added.length && !diff.removed.length && !diff.policy_changed && !diff.logging_changed) {
    diffHtml += `<li>(no changes — candidate matches running)</li>`;
  }
  diffHtml += `</ul>`;
  diffSec.innerHTML = diffHtml;
  body.appendChild(diffSec);
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s;
  return div.innerHTML;
}

// ------------------------------------------------------ table search ----

const tableFilters = {}; // tableId -> [filterText per column index]

function wireTableSearch(tableId, numColumns, searchableIndices) {
  tableFilters[tableId] = new Array(numColumns).fill("");
  const thead = $(`#${tableId} thead`);
  const filterRow = document.createElement("tr");
  filterRow.className = "search-row";
  for (let i = 0; i < numColumns; i++) {
    const th = document.createElement("th");
    if (searchableIndices.includes(i)) {
      const input = document.createElement("input");
      input.type = "text";
      input.placeholder = "search…";
      input.className = "table-search-input";
      input.addEventListener("input", () => {
        tableFilters[tableId][i] = input.value.toLowerCase();
        applyTableFilter(tableId);
      });
      th.appendChild(input);
    }
    filterRow.appendChild(th);
  }
  thead.appendChild(filterRow);
}

function applyTableFilter(tableId) {
  const filters = tableFilters[tableId];
  if (!filters) return;
  $$(`#${tableId} tbody tr`).forEach(tr => {
    const cells = tr.children;
    let visible = true;
    for (let i = 0; i < filters.length; i++) {
      if (!filters[i]) continue;
      const text = (cells[i] ? cells[i].textContent : "").toLowerCase();
      if (!text.includes(filters[i])) { visible = false; break; }
    }
    tr.style.display = visible ? "" : "none";
  });
}

// ------------------------------------------------------------ port map ----

function renderPortmapTable(entries) {
  const tbody = $("#portmap-rows");
  tbody.innerHTML = "";
  entries.forEach(e => {
    const tr = document.createElement("tr");
    tr.dataset.key = `${e.proto}:${e.addr}:${e.port}`;
    const verdictLabel = (PortMap.LABELS[e.verdict] || e.verdict).split(" (")[0];
    const scopeLabel = { loopback: "off-box only", none: "nobody", lan: "LAN only",
      restricted: "one address", any: "ANY SOURCE" }[e.scope] || e.scope;
    tr.innerHTML = `
      <td>${e.port}${e.is_new ? '<span class="pill-new">NEW</span>' : ""}</td>
      <td>${e.proto.toUpperCase()}</td>
      <td>${escapeHtml(e.addr)}</td>
      <td>${escapeHtml(e.process || "—")}</td>
      <td>${e.docker ? escapeHtml(e.docker.container) : "—"}</td>
      <td class="pill-verdict-${e.verdict}">${escapeHtml(verdictLabel)}</td>
      <td class="pill-scope-${e.scope}">${escapeHtml(scopeLabel)}</td>
    `;
    tbody.appendChild(tr);
  });
  applyTableFilter("portmap-table");
}

function highlightPortmapRow(entry) {
  const key = `${entry.proto}:${entry.addr}:${entry.port}`;
  $$("#portmap-rows tr").forEach(tr => tr.style.background = "");
  const row = $(`#portmap-rows tr[data-key="${CSS.escape(key)}"]`);
  if (row) {
    row.style.background = "rgba(46,230,255,0.12)";
    row.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
}

async function loadPortmap() {
  const meta = $("#portmap-meta");
  const notices = $("#portmap-notices");
  const against = $("#chk-preview-candidate").checked ? "candidate" : "running";
  meta.textContent = "scanning…";
  try {
    const result = await api(`/api/portmap?against=${against}`);
    const againstLabel = against === "candidate" ? "CANDIDATE (preview, not live)" : "RUNNING (live)";
    meta.textContent = `${result.entries.length} sockets vs ${againstLabel} — scanned ${new Date(result.scanned_at * 1000).toLocaleTimeString()}`;

    notices.innerHTML = "";
    if (against === "candidate") {
      notices.innerHTML += `<div class="notice warn">⚠ Previewing your uncommitted CANDIDATE changes — this is not what's actually live. "NEW" badges reflect the last RUNNING scan, not this preview.</div>`;
    }
    if (!result.pid_visibility) {
      notices.innerHTML += `<div class="notice warn">⚠ No process names available — add <code>pid: "host"</code> in docker-compose.yml and recreate the container.</div>`;
    }
    if (!result.docker_available) {
      notices.innerHTML += `<div class="notice">ℹ Docker socket not reachable — container attribution disabled. Mount /var/run/docker.sock (read-only) to enable it.</div>`;
    }

    PortMap.render($("#portmap-svg"), result.entries, (e) => highlightPortmapRow(e));
    renderPortmapTable(result.entries);
  } catch (e) {
    meta.textContent = "";
    notices.innerHTML = `<div class="notice warn">⚠ ${escapeHtml(e.message)}</div>`;
  }
}

function wireEvents() {
  $("#btn-refresh").addEventListener("click", () => refreshState().then(() => toast("Synced.")));

  $("#add-rule-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const body = Object.fromEntries(fd.entries());
    try {
      await api("/api/candidate/rules", { method: "POST", body: JSON.stringify(body) });
      e.target.reset();
      $('[name="from_ip"]', e.target).value = "any";
      $('[name="to_ip"]', e.target).value = "any";
      await refreshState();
      toast("Rule added to candidate.");
    } catch (err) {
      toast(err.message, "error");
    }
  });

  $("#btn-discard").addEventListener("click", async () => {
    if (!confirm("Discard all candidate changes and reset to running config?")) return;
    await api("/api/candidate/discard", { method: "POST" });
    await refreshState();
    toast("Candidate reset to running config.");
  });

  $("#btn-validate").addEventListener("click", async () => {
    try {
      const result = await api("/api/candidate/validate", { method: "POST" });
      renderValidationReport(result);
      $("#validate-modal").classList.remove("hidden");
    } catch (e) {
      toast(e.message, "error");
    }
  });

  $("#btn-close-validate").addEventListener("click", () => $("#validate-modal").classList.add("hidden"));
  $("#btn-close-validate-2").addEventListener("click", () => $("#validate-modal").classList.add("hidden"));

  $("#btn-commit").addEventListener("click", async () => {
    if (!confirm("Commit candidate config? This resets and reapplies the live firewall.")) return;
    try {
      const res = await api("/api/commit", { method: "POST" });
      await refreshState();
      const secs = res.pending_commit.seconds_left;
      if (secs > 0) {
        toast(`Committed. Confirm within ${secs}s or it auto-reverts.`, "success");
      } else {
        toast("Committed.", "success");
      }
    } catch (e) {
      if (e.body && e.body.validation) {
        renderValidationReport(e.body.validation);
        $("#validate-modal").classList.remove("hidden");
        toast("Commit blocked — fix validation errors first.", "error");
      } else {
        toast(e.message, "error");
      }
    }
  });

  $("#btn-keep").addEventListener("click", async () => {
    await api("/api/commit/confirm", { method: "POST" });
    await refreshState();
    toast("Changes kept.", "success");
  });

  $("#btn-revert-now").addEventListener("click", async () => {
    if (!confirm("Revert immediately to the previous running config?")) return;
    await api("/api/commit/revert", { method: "POST" });
    await refreshState();
    toast("Reverted to previous running config.");
  });

  $("#btn-toggle-raw").addEventListener("click", async () => {
    const pre = $("#raw-status");
    if (pre.classList.contains("hidden")) {
      const { raw } = await api("/api/ufw/raw");
      pre.textContent = raw;
      pre.classList.remove("hidden");
    } else {
      pre.classList.add("hidden");
    }
  });

  $("#btn-ufw-disable").addEventListener("click", async () => {
    if (!confirm("DISABLE the firewall entirely, right now? This bypasses commit/rollback.")) return;
    await api("/api/ufw/disable", { method: "POST" });
    toast("Firewall disabled.", "error");
    refreshState();
  });

  $("#btn-ufw-enable").addEventListener("click", async () => {
    await api("/api/ufw/enable", { method: "POST" });
    toast("Firewall enabled.", "success");
    refreshState();
  });

  $("#btn-scan-ports").addEventListener("click", () => loadPortmap());
  $("#btn-pm-zoom-in").addEventListener("click", () => PortMap.zoomIn());
  $("#btn-pm-zoom-out").addEventListener("click", () => PortMap.zoomOut());
  $("#btn-pm-zoom-reset").addEventListener("click", () => PortMap.resetView());
  $("#chk-preview-candidate").addEventListener("change", () => loadPortmap());

  wireCandidateDragReorder();
  wireTableSearch("candidate-table", 11, [2, 3, 4, 5, 6, 7, 8]);
  wireTableSearch("running-table", 8, [0, 1, 2, 3, 4, 5, 6]);
  wireTableSearch("portmap-table", 7, [0, 1, 2, 3, 4, 5, 6]);

  $("#rule-preset-select").addEventListener("change", (ev) => {
    const preset = RULE_PRESETS[ev.target.value];
    if (!preset) return;
    const form = $("#add-rule-form");
    form.proto.value = preset.proto;
    form.port.value = preset.port;
    if (!form.comment.value) form.comment.value = preset.comment;
    ev.target.value = "";
  });

  $("#btn-export").addEventListener("click", () => {
    const a = document.createElement("a");
    a.href = "/api/candidate/export";
    document.body.appendChild(a);
    a.click();
    a.remove();
  });

  $("#btn-import").addEventListener("click", () => $("#import-file-input").click());
  $("#import-file-input").addEventListener("change", async (ev) => {
    const file = ev.target.files[0];
    if (!file) return;
    try {
      const json = JSON.parse(await file.text());
      await api("/api/candidate/import", { method: "POST", body: JSON.stringify(json) });
      await refreshState();
      toast("Candidate config imported.", "success");
    } catch (e) {
      const msg = (e.body && e.body.message) ? e.body.message
        : (e.body && e.body.validation) ? e.body.validation.errors.join(" ")
        : (e.message || "invalid JSON file");
      toast("Import failed: " + msg, "error");
    } finally {
      ev.target.value = "";
    }
  });

  $("#btn-test-connection").addEventListener("click", () => {
    $("#testconn-result").classList.add("hidden");
    $("#testconn-modal").classList.remove("hidden");
  });
  $("#btn-close-testconn").addEventListener("click", () => $("#testconn-modal").classList.add("hidden"));
  $("#btn-close-testconn-2").addEventListener("click", () => $("#testconn-modal").classList.add("hidden"));

  $("#testconn-form").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const body = Object.fromEntries(new FormData(ev.target).entries());
    const resultEl = $("#testconn-result");
    resultEl.classList.remove("hidden");
    try {
      const res = await api("/api/test-connection", { method: "POST", body: JSON.stringify(body) });
      resultEl.className = "testconn-result tc-" + res.action;
      resultEl.innerHTML = `<div class="tc-verdict">${escapeHtml(res.action.toUpperCase())}</div>`
        + `<div class="tc-explain">${escapeHtml(res.explanation)}</div>`;
    } catch (e) {
      resultEl.className = "testconn-result tc-error";
      const msg = (e.body && e.body.errors) ? e.body.errors.join(" ") : e.message;
      resultEl.innerHTML = `<div class="tc-verdict">INVALID INPUT</div><div class="tc-explain">${escapeHtml(msg)}</div>`;
    }
  });
}

const RULE_PRESETS = {
  ssh: { proto: "tcp", port: "22", comment: "SSH" },
  http: { proto: "tcp", port: "80", comment: "HTTP" },
  https: { proto: "tcp", port: "443", comment: "HTTPS" },
  dns: { proto: "any", port: "53", comment: "DNS" },
  "docker-registry": { proto: "tcp", port: "5000", comment: "Docker Registry" },
  plex: { proto: "tcp", port: "32400", comment: "Plex" },
  wireguard: { proto: "udp", port: "51820", comment: "WireGuard" },
  minecraft: { proto: "tcp", port: "25565", comment: "Minecraft" },
};

wireEvents();
refreshState().catch(e => toast(e.message, "error"));
loadPortmap();

pollTimer = setInterval(() => {
  api("/api/state").then(state => updateCommitBar(state.pending_commit)).catch(() => {});
}, 5000);

import ipaddress
import re
import secrets
import shlex
import subprocess

VALID_ACTIONS = {"allow", "deny", "reject", "limit"}
VALID_PROTO = {"any", "tcp", "udp"}
VALID_POLICY = {"allow", "deny", "reject"}
VALID_LOGGING = {"off", "low", "medium", "high", "full"}


def run_ufw(args, timeout=20):
    cmd = ["ufw"] + args
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {"cmd": " ".join(cmd), "rc": res.returncode,
                "out": res.stdout.strip(), "err": res.stderr.strip()}
    except Exception as e:
        return {"cmd": " ".join(cmd), "rc": -1, "out": "", "err": str(e)}


def get_raw_status():
    res = run_ufw(["status", "verbose"])
    return res["out"] or res["err"]


# ---------------------------------------------------- docker-user hook ----
#
# Docker's published ports bypass ufw entirely by default: the DNAT rewrite
# happens in PREROUTING before the kernel picks INPUT vs FORWARD, so the
# traffic takes the FORWARD path and never touches ufw's INPUT-chain rules
# at all. This hook makes the DOCKER-USER chain (which Docker creates and
# consults first, before its own permissive rules) fall through to ufw's
# own `ufw-user-forward` chain — the same chain `ufw route allow` already
# populates — and DROP anything that isn't explicitly allowed there.
#
# Deliberately narrower than the upstream chaifeng/ufw-docker project: that
# project auto-allows all of 10/8, 172.16/12, 192.168/16 by default, which
# would make every Docker-published port reachable from this LAN with zero
# explicit rule — the opposite of "only expose what's required." Nothing
# gets through here except what has an explicit `docker_forward` rule.
#
# `ufw --force reset` restores /etc/ufw/after.rules from the packaged
# default template, wiping this block — so it must be re-asserted on every
# apply_config() call, not installed once.

AFTER_RULES_PATH = "/etc/ufw/after.rules"
_HOOK_BEGIN = "# BEGIN UFW-WEBUI DOCKER-USER HOOK"
_HOOK_END = "# END UFW-WEBUI DOCKER-USER HOOK"
_HOOK_LINES = [
    ":DOCKER-USER - [0:0]",
    "-A DOCKER-USER -j ufw-user-forward",
    "-A DOCKER-USER -m conntrack --ctstate RELATED,ESTABLISHED -j RETURN",
    "-A DOCKER-USER -m conntrack --ctstate INVALID -j DROP",
    "-A DOCKER-USER -i docker0 -o docker0 -j ACCEPT",
    "-A DOCKER-USER -j DROP",
]


def ensure_docker_user_hook(present):
    """Install or remove the DOCKER-USER hook block in after.rules,
    idempotently. `present=False` when no enabled rule currently needs it,
    so hosts that never use this feature see zero behavior change."""
    try:
        with open(AFTER_RULES_PATH, "r") as f:
            content = f.read()
    except OSError as e:
        return {"cmd": "ensure_docker_user_hook", "rc": -1, "out": "", "err": str(e)}

    has_marker = _HOOK_BEGIN in content

    if present == has_marker:
        return {"cmd": "ensure_docker_user_hook", "rc": 0,
                "out": "already " + ("present" if present else "absent"), "err": ""}

    if not present:
        start = content.index(_HOOK_BEGIN)
        end = content.index(_HOOK_END) + len(_HOOK_END)
        # also eat one trailing newline so repeated install/remove doesn't
        # accumulate blank lines
        tail = content[end:]
        if tail.startswith("\n"):
            tail = tail[1:]
        new_content = content[:start] + tail
        try:
            with open(AFTER_RULES_PATH, "w") as f:
                f.write(new_content)
        except OSError as e:
            return {"cmd": "ensure_docker_user_hook", "rc": -1, "out": "", "err": str(e)}
        return {"cmd": "ensure_docker_user_hook", "rc": 0, "out": "removed", "err": ""}

    lines = content.splitlines(keepends=True)
    commit_idx = None
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip() == "COMMIT":
            commit_idx = i
            break
    if commit_idx is None:
        return {"cmd": "ensure_docker_user_hook", "rc": -1, "out": "",
                "err": "no COMMIT line found in after.rules"}

    block = "\n".join([_HOOK_BEGIN] + _HOOK_LINES + [_HOOK_END]) + "\n\n"
    new_lines = lines[:commit_idx] + [block] + lines[commit_idx:]
    try:
        with open(AFTER_RULES_PATH, "w") as f:
            f.writelines(new_lines)
    except OSError as e:
        return {"cmd": "ensure_docker_user_hook", "rc": -1, "out": "", "err": str(e)}
    return {"cmd": "ensure_docker_user_hook", "rc": 0, "out": "installed", "err": ""}


def build_docker_route_args(rule):
    """Build a `ufw route <action> ...` command for a docker_forward rule
    by resolving the rule's port to whichever running container currently
    publishes it. Returns None (caller should skip + log) if nothing
    resolves, e.g. the container isn't running or the port is a range."""
    import port_scanner  # local import: port_scanner imports this module too

    proto = rule.get("proto") or "tcp"
    if proto == "any":
        proto = "tcp"
    resolved = port_scanner.resolve_container_ip_for_port(proto, rule.get("port"))
    if not resolved:
        return None
    ip, container_port = resolved

    # No "in"/"out" token here: unlike plain `ufw allow`, that's not
    # verified syntax for `ufw route` (docker_forward only ever models
    # inbound-to-a-published-port traffic anyway, which is what this
    # produces without it — matches the dry-run tested above exactly).
    args = ["route", rule["action"]]
    args += ["from", rule.get("from_ip") or "any"]
    args += ["to", ip]
    args += ["port", container_port]
    args += ["proto", proto]
    comment = (rule.get("comment") or "").strip()
    if comment:
        args += ["comment", comment[:200]]
    return args


def build_rule_args(rule):
    args = [rule["action"]]
    args.append("out" if rule.get("direction") == "out" else "in")
    args += ["from", rule.get("from_ip") or "any"]
    args += ["to", rule.get("to_ip") or "any"]
    port = str(rule.get("port") or "").strip()
    if port:
        args += ["port", port]
    proto = rule.get("proto") or "any"
    if proto != "any":
        args += ["proto", proto]
    comment = (rule.get("comment") or "").strip()
    if comment:
        args += ["comment", comment[:200]]
    return args


def apply_config(cfg):
    """Full reset + reapply, Palo-Alto 'commit renders the whole config' style.
    Returns a command log (list of dicts) for the UI's activity feed."""
    log = [run_ufw(["--force", "reset"])]

    rules = cfg.get("rules", [])
    needs_docker_hook = any(r.get("enabled", True) and r.get("docker_forward") for r in rules)
    log.append(ensure_docker_user_hook(needs_docker_hook))

    pol = cfg.get("policies", {})
    for key in ("incoming", "outgoing"):
        val = pol.get(key)
        if val in VALID_POLICY:
            log.append(run_ufw(["default", val, key]))
    routed = pol.get("routed")
    if routed in VALID_POLICY:
        log.append(run_ufw(["default", routed, "routed"]))

    level = cfg.get("logging", "low")
    if level in VALID_LOGGING:
        log.append(run_ufw(["logging", level]))

    for rule in rules:
        if not rule.get("enabled", True):
            continue
        if rule.get("docker_forward"):
            args = build_docker_route_args(rule)
            if args is None:
                log.append({
                    "cmd": f"(docker_forward rule: port {rule.get('port')}/{rule.get('proto')})",
                    "rc": -1, "out": "",
                    "err": "no running container currently publishes this port - rule skipped",
                })
                continue
            log.append(run_ufw(args))
        else:
            log.append(run_ufw(build_rule_args(rule)))

    log.append(run_ufw(["--force", "enable"]))
    return log


def valid_ip_or_any(val):
    if val in ("any", "", None):
        return True
    try:
        ipaddress.ip_network(val, strict=False)
        return True
    except ValueError:
        return False


def _valid_port(val):
    val = str(val or "").strip()
    if val == "":
        return True
    if ":" in val:
        parts = val.split(":")
        if len(parts) != 2:
            return False
        try:
            a, b = int(parts[0]), int(parts[1])
        except ValueError:
            return False
        return 1 <= a < b <= 65535
    try:
        p = int(val)
        return 1 <= p <= 65535
    except ValueError:
        return False


def port_contains(port_spec, target):
    port_spec = str(port_spec or "").strip()
    if port_spec == "":
        return True
    if ":" in port_spec:
        try:
            a, b = (int(x) for x in port_spec.split(":"))
            return a <= target <= b
        except ValueError:
            return False
    try:
        return int(port_spec) == target
    except ValueError:
        return False


def _addr_matches(rule_addr, test_addr):
    """Does a concrete test address (or CIDR) fall within what a rule's
    from/to field covers? 'any' on either side always matches."""
    if rule_addr in ("any", "", None) or test_addr in ("any", "", None):
        return True
    try:
        rule_net = ipaddress.ip_network(rule_addr, strict=False)
        test_net = ipaddress.ip_network(test_addr, strict=False)
        return rule_net.overlaps(test_net)
    except (ValueError, TypeError):
        return False


def evaluate(rules, policies, direction, proto, port, source_ip, dest_ip="any"):
    """What ufw would actually do for one concrete packet: walks *enabled*
    rules in order and returns the first one whose direction/proto/port/
    from/to all match — mirroring ufw's real first-match-wins semantics,
    including that an earlier broad rule can "shadow" a later, more
    specific one for the same port. Falls back to the direction's default
    policy if nothing matches.

    Returns {"action": "allow"|"deny"|"reject"|"limit", "rule": rule_or_None}.
    This is the one true source of "what does the ruleset say" — both Test
    Connection and the Network Map's per-port verdict/scope are built on it,
    so they can't disagree with each other the way the old port-only scan
    used to (it looked for *any* allow rule mentioning a port and ignored
    order and deny rules entirely, so a deny placed before a broader allow
    for the same port was invisible to it)."""
    policy_key = {"in": "incoming", "out": "outgoing"}.get(direction, "incoming")
    for rule in rules:
        if not rule.get("enabled", True):
            continue
        if rule.get("direction") != direction:
            continue
        if rule.get("proto") not in ("any", proto):
            continue
        if not port_contains(rule.get("port"), port):
            continue
        if not _addr_matches(rule.get("from_ip"), source_ip):
            continue
        if not _addr_matches(rule.get("to_ip"), dest_ip):
            continue
        return {"action": rule.get("action"), "rule": rule}
    return {"action": policies.get(policy_key, "deny"), "rule": None}


def validate_candidate(cfg):
    errors, warnings = [], []
    pol = cfg.get("policies", {})

    for key in ("incoming", "outgoing", "routed"):
        if pol.get(key) not in VALID_POLICY:
            errors.append(f"Policy '{key}' has invalid value '{pol.get(key)}'.")
    if cfg.get("logging") not in VALID_LOGGING:
        errors.append(f"Invalid logging level '{cfg.get('logging')}'.")

    seen_ids = set()
    for i, rule in enumerate(cfg.get("rules", [])):
        label = f"Rule #{i + 1}"
        rid = rule.get("id")
        if rid in seen_ids:
            errors.append(f"{label}: duplicate rule id.")
        seen_ids.add(rid)
        if rule.get("action") not in VALID_ACTIONS:
            errors.append(f"{label}: invalid action '{rule.get('action')}'.")
        if rule.get("direction") not in ("in", "out"):
            errors.append(f"{label}: invalid direction '{rule.get('direction')}'.")
        if rule.get("proto") not in VALID_PROTO:
            errors.append(f"{label}: invalid protocol '{rule.get('proto')}'.")
        if not _valid_port(rule.get("port")):
            errors.append(f"{label}: invalid port '{rule.get('port')}' (use 1-65535 or a:b range).")
        if not valid_ip_or_any(rule.get("from_ip")):
            errors.append(f"{label}: invalid source address '{rule.get('from_ip')}'.")
        if not valid_ip_or_any(rule.get("to_ip")):
            errors.append(f"{label}: invalid destination address '{rule.get('to_ip')}'.")
        if (rule.get("enabled", True) and rule.get("direction") == "in"
                and rule.get("action") == "allow" and not str(rule.get("port") or "").strip()
                and (rule.get("from_ip") or "any") == "any"):
            warnings.append(f"{label}: allows ALL inbound traffic from ANY source — very permissive.")
        if rule.get("enabled", True) and rule.get("docker_forward"):
            import port_scanner  # local import: avoids a module-load circular import
            proto = rule.get("proto") or "tcp"
            resolved = port_scanner.resolve_container_ip_for_port(
                "tcp" if proto == "any" else proto, rule.get("port"))
            if not resolved:
                warnings.append(
                    f"{label}: marked 'allow through Docker' but no running container currently "
                    f"publishes {rule.get('port')}/{proto} — this rule will be skipped on commit.")

    if pol.get("incoming") == "deny":
        active = [r for r in cfg.get("rules", [])
                  if r.get("enabled", True) and r.get("direction") == "in"
                  and r.get("action") in ("allow", "limit")]

        def allows(port, proto):
            for r in active:
                if r.get("proto") not in ("any", proto):
                    continue
                if port_contains(r.get("port"), port):
                    return True
            return False

        if not allows(22, "tcp"):
            warnings.append(
                "No inbound rule allows TCP/22 (SSH) — you may lose remote access after commit.")

    return {"errors": errors, "warnings": warnings}


SIG_FIELDS = ("action", "direction", "proto", "port", "from_ip", "to_ip")


def _sig(rule):
    return tuple(str(rule.get(f) or "").lower() for f in SIG_FIELDS)


def diff_configs(running, candidate):
    run_rules = [r for r in running.get("rules", []) if r.get("enabled", True)]
    cand_rules = [r for r in candidate.get("rules", []) if r.get("enabled", True)]
    run_sigs = {_sig(r): r for r in run_rules}
    cand_sigs = {_sig(r): r for r in cand_rules}

    added = [r for sig, r in cand_sigs.items() if sig not in run_sigs]
    removed = [r for sig, r in run_sigs.items() if sig not in cand_sigs]
    unchanged = len(cand_sigs) - len(added)

    return {
        "added": added,
        "removed": removed,
        "unchanged": max(0, unchanged),
        "policy_changed": running.get("policies") != candidate.get("policies"),
        "logging_changed": running.get("logging") != candidate.get("logging"),
    }


def parse_ufw_command_line(line):
    """Best-effort parse of a line from `ufw show added`, e.g.:
    'ufw allow from 10.0.0.0/8 to any port 22 proto tcp comment X'
    'ufw allow 80/tcp'
    Returns a rule dict, or None if it doesn't look like a rule we understand.
    """
    line = line.strip()
    if not line.startswith("ufw "):
        return None
    try:
        tokens = shlex.split(line)
    except ValueError:
        return None
    if len(tokens) < 2:
        return None

    i = 1
    action = tokens[i]
    if action not in VALID_ACTIONS:
        return None
    i += 1

    rule = {"action": action, "direction": "in", "proto": "any", "port": "",
            "from_ip": "any", "to_ip": "any", "comment": "", "enabled": True}

    if i < len(tokens) and tokens[i] in ("in", "out"):
        rule["direction"] = tokens[i]
        i += 1

    if i < len(tokens) and tokens[i] in ("from", "to"):
        # Extended form: "from ADDR [port P] [proto PR]" and/or
        # "to ADDR [port P] [proto PR]" — either clause may appear alone
        # (e.g. `ufw deny out to any port 53 proto udp` has no `from`).
        if tokens[i] == "from":
            i += 1
            if i < len(tokens):
                rule["from_ip"] = tokens[i]
                i += 1
            if i < len(tokens) and tokens[i] == "port":
                i += 1
                rule["port"] = tokens[i] if i < len(tokens) else ""
                i += 1
            if i < len(tokens) and tokens[i] == "proto":
                i += 1
                rule["proto"] = tokens[i] if i < len(tokens) else "any"
                i += 1
        if i < len(tokens) and tokens[i] == "to":
            i += 1
            if i < len(tokens):
                rule["to_ip"] = tokens[i]
                i += 1
            if i < len(tokens) and tokens[i] == "port":
                i += 1
                rule["port"] = tokens[i] if i < len(tokens) else ""
                i += 1
            if i < len(tokens) and tokens[i] == "proto":
                i += 1
                rule["proto"] = tokens[i] if i < len(tokens) else "any"
                i += 1
    elif i < len(tokens) and tokens[i] != "comment":
        spec = tokens[i]
        i += 1
        if "/" in spec:
            port, proto = spec.split("/", 1)
            rule["port"] = port
            rule["proto"] = proto
        else:
            rule["port"] = spec

    if i < len(tokens) and tokens[i] == "comment" and i + 1 < len(tokens):
        rule["comment"] = tokens[i + 1]

    return rule


def import_from_host():
    """Best-effort snapshot of whatever ufw config already exists on the host,
    used only on first boot before this tool has ever committed anything."""
    verbose = run_ufw(["status", "verbose"])["out"]

    policies = {"incoming": "deny", "outgoing": "allow", "routed": "deny"}
    logging_level = "low"

    m = re.search(
        r"Default:\s*(\w+)\s*\(incoming\),\s*(\w+)\s*\(outgoing\),\s*(\w+)\s*\(routed\)",
        verbose)
    if m:
        inc, out, routed = m.groups()
        policies["incoming"] = inc if inc in VALID_POLICY else "deny"
        policies["outgoing"] = out if out in VALID_POLICY else "allow"
        policies["routed"] = routed if routed in VALID_POLICY else "deny"

    lm = re.search(r"Logging:\s*(on|off)(?:\s*\((\w+)\))?", verbose)
    if lm:
        if lm.group(1) == "off":
            logging_level = "off"
        elif lm.group(2) in VALID_LOGGING:
            logging_level = lm.group(2)

    added = run_ufw(["show", "added"])["out"]
    rules = []
    for line in added.splitlines():
        line = line.strip()
        if not any(line.startswith(f"ufw {a}") for a in VALID_ACTIONS):
            continue
        parsed = parse_ufw_command_line(line)
        if parsed:
            parsed["id"] = secrets.token_hex(4)
            rules.append(parsed)

    return {"policies": policies, "logging": logging_level, "rules": rules}

# UFW Command Deck

A fast, self-contained web front-end for `ufw` on the host machine, with a
Palo-Alto-style **candidate / running** config split:

- **Candidate config** — what you're editing. Nothing on the host changes
  until you commit it.
- **Running config** — what's actually live on the host firewall right now.
- **Validate** — checks the candidate for bad ports/CIDRs/policies and shows
  a diff against running, without touching the host.
- **Commit** — applies the candidate (`ufw reset` + reapply the whole
  candidate, then `ufw enable`) so running == candidate, exactly.
- **Commit-confirm timer** — after a commit, you have `COMMIT_CONFIRM_SECONDS`
  (default 90) to click **Keep Changes**. If you don't (e.g. because the new
  rules just cut off your access to this very UI), it **automatically
  reverts** to the pre-commit config. This is the single most important
  safety feature here — firewall changes are the classic way to lock
  yourself out of a box.

No build step, no JS framework, no CDN calls: it's Flask + vanilla
HTML/CSS/JS, so it runs the same online or fully air-gapped.

## Network Map

A left-to-right flow diagram — **LAN → UFW → each listening port**, or
**LAN → UFW → DOCKER → CONTAINER → port** for anything Docker-published —
one row per port, built from the host's *actual* listening sockets, read
straight out of `/proc/net/{tcp,tcp6,udp,udp6}`, which this container
already sees since it shares the host's network namespace. Click
**Scan Ports** to refresh it. Ports are sorted most-exposed-first, so
anything reachable from outside your LAN clusters at the top. A container
with multiple published ports gets one shared CONTAINER node that all of
them converge on; hover it to trace every port that container owns.

**LAN is the one network entry node** — there's only one physical way into
this host, so it's represented as one node rather than splitting "LAN
traffic" and "internet traffic" into two. What distinguishes them is the
**edge color** wired back from each reachable port:

- blue edge — the matching rule's source is a private/link-local range
  (RFC1918, CGNAT, `fe80::/10`/`fc00::/7`, etc.): reachable from other
  machines on your network, not from outside it.
- amber dashed edge — restricted to one specific public address/range:
  reachable from outside, but only from that address.
- **bold red edge** — the rule (or default policy) allows `any` source.
  This is the thing worth checking: it means ufw (and Docker, if it
  applies) would let a connection through from anywhere. Whether it's
  *actually* reachable from the internet still depends on your router/NAT
  forwarding that port — this host has no visibility into that, so treat a
  red edge as "verify this is intentional," not "this is definitely on the
  internet." The LAN node itself pulses red the moment anything has a red
  edge, and sits calm otherwise — a glance at that one node tells you your
  overall exposure posture.

Each line literally bends at the **UFW** node (and, for Docker ports, at
**DOCKER** and the owning **CONTAINER** node too) rather than cutting
straight across, so it reads as source → gate → [docker → container →]
service, the way traffic actually goes. Every port is also cross-referenced
against the running ufw config for a node color that reflects what's
actually true, not just what the ruleset says:

- **allowed by rule** / **allowed by default policy** — ufw is letting it through.
- **blocked** — default-deny incoming, no rule matches. Ufw is doing its job.
- **loopback only** — bound to a loopback address, not reachable regardless of ufw.
- **DOCKER — bypasses ufw** — a container publishes this port. Docker's
  published ports get NAT'd in the `PREROUTING` chain *before* the kernel
  decides between `INPUT` and `FORWARD` — since the rewritten destination
  is the container's own IP, that traffic takes the `FORWARD` path, which
  ufw's normal `allow`/`deny` rules (built for `INPUT`) never see, no
  matter what your rule table says. This is real and unconditional *unless*
  you've separately added rules to the `DOCKER-USER` chain that intercept
  it first — the well-known [ufw-docker](https://github.com/chaifeng/ufw-docker)
  fix. The tool checks for that: if `DOCKER-USER` has more than Docker's
  own default single `RETURN` rule, a notice above the graph says so — but
  it's a heuristic (something was added, not proof it covers this specific
  port), so every Docker-published port still gets flagged either way. A
  flag here means "verify this one," never "this one is definitely open,"
  and it means that regardless of whether you also happened to write a ufw
  rule for that same port — the rule doesn't govern this traffic at all in
  the unmitigated default.

Hover a port node to see just its own edges highlighted, or a CONTAINER
node to highlight every port that container owns. The DOCKER/CONTAINER
columns only appear at all when at least one listening port is actually
Docker-published — a bare-metal host with nothing containerized just shows
the shorter LAN → UFW → port flow. The table's **REACHABLE FROM** column
gives the same reachability answer in text.

**Navigating a busy graph:**

- **Zoom** — scroll the wheel over the canvas (zooms toward the cursor), or
  use the +/−/reset buttons in the corner.
- **Pan** — drag empty canvas background.
- **Rearrange** — drag any node; the lines through it follow live. This is
  purely a viewing aid for the current scan, not a saved layout — the next
  **Scan Ports** (or a collapse toggle, since that changes which nodes
  exist) lays everything out fresh.
- **Collapse** — click **UFW**, **DOCKER**, or a container node to hide
  everything behind it (the lines feeding it stay, just truncated at that
  node, with a "+N hidden" count) — click again to expand. Collapsing UFW
  hides the entire service graph down to just the LAN node;
  collapsing DOCKER hides every container and its ports but leaves native
  host services alone; collapsing one container hides only its own ports.

Two things are needed for full attribution, both real privilege bumps on an
already-privileged container (see `docker-compose.yml` for exactly what's
added and why):

- **Process names** (e.g. `sshd`, `nginx`) need `pid: "host"` — visibility
  into every host process's fd table, which also means visibility into
  every host process's command line.
- **Container attribution** needs a read-only `/var/run/docker.sock` mount.
  Read-only meaningfully limits, but does not by itself guarantee, that
  nothing on this socket can be used for control. If that trade-off doesn't
  sit well with you, a read-only socket proxy (e.g.
  `tecnativo/docker-socket-proxy`) in front of it is a stronger boundary —
  not set up here, but worth knowing about. The panel degrades gracefully
  with either or both left off — you just lose that column's attribution.

## Architecture note — why `network_mode: host`

`ufw` is a wrapper around `iptables`/`nft`. For rules set *inside* the
container to actually govern the *host's* traffic, the container has to
share the host's network namespace (`network_mode: host`) and hold
`NET_ADMIN`/`NET_RAW`. `/etc/ufw` and `/var/lib/ufw` are bind-mounted so the
`ufw` binary in the container and any `ufw` on the host agree on state.

**This means the container is effectively as trusted as root on the host
network stack.** Treat it accordingly:

- Set `WEBUI_PASSWORD` in `docker-compose.yml` to a real password (otherwise
  one is randomly generated on first boot and printed once to `docker logs`,
  then stored hashed in the `/data` volume).
- Don't expose the port to the open internet. Put it behind a VPN, bind it
  to localhost/LAN only, or front it with a reverse proxy that adds TLS +
  another auth layer.
- The commit-confirm timer helps with *accidental* lockouts, not with
  someone else having your password.

## First run

```bash
docker compose up -d --build
docker compose logs -f ufw-webui   # grab the generated password on first boot
```

Then open `http://<host>:8787`.

On first boot (before this tool has ever committed anything), it does a
best-effort import of whatever `ufw` rules already exist on the host, so you
start from your real current state instead of a blank slate. Import parsing
is best-effort — check the Running Config panel and the raw `ufw status`
view after first boot to confirm it looks right.

## Using it

1. Edit rules and default policies in **Candidate Config** (left panel).
   Nothing is live yet.
2. Click **Validate** to check for typos and see a diff vs. what's running.
3. Click **Commit**. Changes go live immediately.
4. Click **Keep Changes** within the countdown window, or it auto-reverts.

Full ordered rule list, in/out direction, tcp/udp/any, ports or ranges
(`8000:9000`), source/destination CIDRs, comments, and enable/disable per
rule (kept but skipped on commit, so you can stage a rule without applying
it) are all supported.

**Danger zone**: a separate "disable firewall entirely" toggle bypasses
candidate/commit for the rare case you need the firewall off right now. It
takes effect immediately with no confirm timer — use deliberately.

**Network Map** (below the candidate/running panels): click **Scan Ports**
any time to see what's actually listening on the host right now, cross-
checked against the config above. See the Network Map section above for
what each color means.

**Rule reordering**: drag the ⋮⋮ handle on any Candidate row. Order isn't
cosmetic — ufw is first-match, so a `deny` above a broader `allow` for the
same port makes that allow dead. Reorder freely; it saves immediately.

**Table search**: every rule/port table has a per-column search row under
its headers — type in any combination of columns and rows are filtered by
all of them at once (AND, not OR).

**Preview Candidate on the Network Map**: the "PREVIEW CANDIDATE" checkbox
above the map switches it from showing live RUNNING exposure to showing
what your *uncommitted* Candidate edits would look like once applied — see
the impact before you commit, not after. "NEW" badges (see below) only
ever track the live RUNNING state, not this preview.

**New-port drift detection**: every RUNNING scan (not Candidate previews)
is compared against the previous one; anything listening now that wasn't
there last time gets a pulsing NEW badge in the table and a pulsing
magenta ring on its graph node. This resets what counts as "new" each time
you scan — it's "what changed since I last looked," not a permanent log.

**Export / Import**: EXPORT downloads the current Candidate as JSON;
IMPORT loads one back in (from this tool or hand-written, as long as it's
`{policies, logging, rules}`) — runs through the same validation as any
other edit, and replaces the current Candidate entirely rather than
merging. Handy for backing up a config outside this tool, or copying one
between machines.

**Quick-add presets**: the dropdown next to the rule form pre-fills
port/protocol/comment for common services (SSH, HTTP/S, DNS, Plex,
WireGuard, etc.) — review and click **+ ADD RULE** yourself, nothing
applies automatically.

## Test Connection

A policy simulator, similar in spirit to what enterprise firewalls call
"test policy match": click **🔌 TEST CONNECTION** (top bar) any time and
give it a source address, optional destination, port, protocol, and
direction. It walks the **live RUNNING ruleset** — always running, never
candidate, so the answer matches what would actually happen right now —
using the exact same first-match, order-aware evaluation engine the
Network Map uses internally, and tells you which rule (if any) decided the
outcome, or that it fell through to the default policy.

This is the precise, single-address complement to the Network Map's
broader per-port summary: the map answers "roughly who can reach this
port," Test Connection answers "can *this exact* source reach *this exact*
port" with the actual matched rule shown.

## Configuration (env vars)

| Var | Default | Meaning |
|---|---|---|
| `WEBUI_PORT` | `8787` | Port the app listens on (host port, since networking is host-mode) |
| `COMMIT_CONFIRM_SECONDS` | `90` | Auto-revert window after commit. `0` disables the safety net (commits are final immediately) |
| `WEBUI_PASSWORD` | *(random, generated once)* | Login password |
| `DATA_DIR` | `/data` | Where candidate/running/snapshot state and the auth secret live |

## Limitations

- Single gunicorn worker by design — the commit-confirm timer lives in
  process memory, so it can't be sharded across workers. This is a
  single-admin LAN tool, not built for concurrency.
- Import of pre-existing rules on first boot is best-effort text parsing of
  `ufw show added`; unusual/manual rules may not round-trip perfectly. After
  first commit, the tool fully owns the config and this doesn't matter
  anymore (running is always exactly what was last committed here).
- Only destination-port matching is exposed in the UI (the common case).
  Source-port rules aren't supported through the form.
- The Network Map's "blocked"/"allowed" verdicts reflect *this tool's*
  model of the ufw config (`running.json`). If something else on the box
  edits iptables/nft rules directly (outside ufw, outside this tool), the
  verdict shown here can be wrong. The `DOCKER-USER` mitigation check is a
  heuristic (rule count beyond Docker's default) — it can tell you
  *something* was added, never that it actually covers a given port, so
  Docker-published ports stay flagged either way — see the Network Map
  section above.
- Port scanning is manual (click **Scan Ports**), not auto-polled — it walks
  `/proc` for every host process and optionally calls the Docker API, which
  is unnecessary overhead to run on a timer for a panel you're not looking at.
- LAN-only vs. specific-address vs. any-source is classified by address
  range (RFC1918/link-local = LAN, everything else = restricted/any), not
  by asking your router what it actually forwards. A rule source it can't
  parse is treated as `any` (fail open — flagged rather than silently
  hidden), same philosophy as everywhere else in this tool.
